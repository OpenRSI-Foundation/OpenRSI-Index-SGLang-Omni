# SPDX-License-Identifier: Apache-2.0
"""MOSS-TTS Local SGLang engine builder."""

from __future__ import annotations

import importlib
from collections.abc import Callable, Mapping
from typing import TYPE_CHECKING

from sglang.srt.server_args import ServerArgs

from sglang_omni.model_runner.model_worker import ModelWorker
from sglang_omni.models.moss_tts.hf_loading import (
    MOSS_TTS_DEFAULT_CONTEXT_LENGTH,
    resolve_moss_tts_context_length,
)
from sglang_omni.models.moss_tts_local import request_builders
from sglang_omni.models.moss_tts_local import stages as moss_local_stages
from sglang_omni.models.moss_tts_local.request_builders import (
    MossTTSLocalSGLangRequestData,
)
from sglang_omni.proto.request import StagePayload
from sglang_omni.scheduling.bootstrap import InfrastructureOptions
from sglang_omni.scheduling.engine_factory import (
    GenerationDefaults,
    SchedulerExtras,
    TtsEngineBuilder,
)

if TYPE_CHECKING:
    from sglang.srt.hardware_backend.mlx.tp_worker import MlxTpModelWorker

    from sglang_omni.models.moss_tts_local.model_runner import MossTTSLocalModelRunner
    from sglang_omni.models.moss_tts_local.sglang_model import MossTTSLocalSGLangModel
    from sglang_omni.scheduling.omni_scheduler import OmniScheduler
    from sglang_omni.scheduling.sglang_backend.output_processor import (
        SGLangOutputProcessor,
    )
else:
    pass


class MossTtsLocalEngineBuilder(TtsEngineBuilder[MossTTSLocalSGLangRequestData]):
    model_name = "MOSS-TTS Local"
    context_length = MOSS_TTS_DEFAULT_CONTEXT_LENGTH
    model_arch_override = "MossTTSLocalSGLangModel"
    supports_context_length_override = True

    def resolve_context_length(
        self,
        checkpoint_dir: str,
        *,
        server_args_overrides: Mapping[str, object] | None = None,
    ) -> int:
        return resolve_moss_tts_context_length(
            checkpoint_dir,
            server_args_overrides=server_args_overrides,
        )

    def __init__(
        self,
        *,
        enable_async_decode: bool,
        async_decode_min_batch_size: int,
        prefill_coalesce_requests: int = 0,
        prefill_coalesce_wait_ms: float = 60.0,
        total_gpu_memory_fraction: float | None,
        codec_mem_reserve: float,
        process_total_gpu_memory_fraction: float | None = None,
    ) -> None:
        self.enable_async_decode = enable_async_decode
        self.async_decode_min_batch_size = async_decode_min_batch_size
        self.prefill_coalesce_requests = prefill_coalesce_requests
        self.prefill_coalesce_wait_ms = prefill_coalesce_wait_ms
        self.total_gpu_memory_fraction = total_gpu_memory_fraction
        self.process_total_gpu_memory_fraction = process_total_gpu_memory_fraction
        self.codec_mem_reserve = codec_mem_reserve
        self.memory_budget = moss_local_stages.ArMemoryBudget(
            effective_total_gpu_memory_fraction=None,
            applied_codec_mem_reserve=0.0,
        )
        self.profile_total_gpu_memory_fraction: float | None = None
        self.model: MossTTSLocalSGLangModel | None = None

    def generation_defaults(
        self,
        *,
        dtype: str,
    ) -> GenerationDefaults:
        defaults: GenerationDefaults = {
            "max_running_requests": 16,
            "dtype": dtype,
            "disable_cuda_graph": False,
            "disable_overlap_schedule": True,
            "max_prefill_tokens": min(self.context_length, 8192),
            "sampling_backend": "pytorch",
            "trust_remote_code": True,
        }
        if self.total_gpu_memory_fraction is None:
            defaults["mem_fraction_static"] = (
                0.6 if moss_local_stages.torch.cuda.device_count() > 1 else 0.5
            )
        else:
            pass
        return defaults

    def adjust_overrides(self, overrides: dict[str, object]) -> None:
        self.memory_budget = moss_local_stages.apply_colocated_ar_memory_budget(
            overrides,
            total_gpu_memory_fraction=self.total_gpu_memory_fraction,
            codec_mem_reserve=self.codec_mem_reserve,
        )
        self.profile_total_gpu_memory_fraction = self.process_total_gpu_memory_fraction
        if (
            self.profile_total_gpu_memory_fraction is None
            and self.memory_budget.effective_total_gpu_memory_fraction is not None
        ):
            self.profile_total_gpu_memory_fraction = (
                self.memory_budget.effective_total_gpu_memory_fraction
            )
        else:
            pass
        if self.profile_total_gpu_memory_fraction is None:
            return
        else:
            pass

        from sglang_omni.utils.gpu_memory import get_process_gpu_memory_bytes

        if get_process_gpu_memory_bytes(self.gpu_id) is None:
            moss_local_stages.logger.warning(
                f"MOSS-TTS Local colocated process memory accounting is unavailable; "
                f"falling back to upstream SGLang free-memory profiling. "
                f"effective_total_gpu_memory_fraction="
                f"{self.profile_total_gpu_memory_fraction}"
            )
            self.profile_total_gpu_memory_fraction = None
        else:
            pass

    def customize_server_args(self, server_args: ServerArgs) -> None:
        from sglang.srt.arg_groups.model_override_base import resolved_view

        cfg = resolved_view(server_args)
        moss_local_stages.logger.info(
            f"MOSS-TTS Local SGLang startup: gpu_id={self.gpu_id} "
            f"total_gpu_memory_fraction={self.total_gpu_memory_fraction} "
            f"effective_total_gpu_memory_fraction="
            f"{self.memory_budget.effective_total_gpu_memory_fraction} "
            f"process_total_gpu_memory_fraction="
            f"{self.process_total_gpu_memory_fraction} "
            f"codec_mem_reserve={self.memory_budget.applied_codec_mem_reserve:.3f} "
            f"mem_fraction_static={cfg.mem_fraction_static} "
            f"profile_total_gpu_memory_fraction="
            f"{self.profile_total_gpu_memory_fraction}"
        )

    def infra_kwargs(self) -> InfrastructureOptions:
        return {
            "total_gpu_memory_fraction": self.profile_total_gpu_memory_fraction,
        }

    def setup_model(
        self,
        *,
        model_worker: ModelWorker | MlxTpModelWorker,
        checkpoint_dir: str,
        device: str,
        gpu_id: int,
        server_args: object,
    ) -> None:
        del checkpoint_dir, device, gpu_id, server_args
        self.model = model_worker.model_runner.model

    def post_cuda_graph_setup(
        self, model: MossTTSLocalSGLangModel, server_args: ServerArgs
    ) -> None:
        from sglang_omni.scheduling.generation_batch_policy import (
            get_decode_cuda_graph_bs,
        )

        batch_sizes = get_decode_cuda_graph_bs(server_args)
        assert batch_sizes is not None

        # note (luojiaxuan): Also graph the per-frame local-transformer decode
        # (1 + n_vq micro-steps and 13 seeded sampling passes per frame):
        # eager it is kernel-launch-bound at ~22 ms/frame independent of batch
        # size.
        model.init_frame_decode_graphs(list(batch_sizes))

    def make_model_runner(
        self,
        model_worker: ModelWorker | MlxTpModelWorker,
        output_proc: SGLangOutputProcessor,
    ) -> MossTTSLocalModelRunner:
        model_runner_mod = importlib.import_module(
            "sglang_omni.models.moss_tts_local.model_runner"
        )

        return model_runner_mod.MossTTSLocalModelRunner(model_worker, output_proc)

    def make_adapters(self, model: MossTTSLocalSGLangModel | None) -> tuple[
        Callable[[StagePayload], MossTTSLocalSGLangRequestData],
        Callable[[MossTTSLocalSGLangRequestData], StagePayload],
    ]:
        return request_builders.make_moss_tts_local_scheduler_adapters(model=model)

    def make_abort_callback(self) -> Callable[[str], None]:
        assert self.model is not None
        model = self.model

        def abort_request(request_id: str) -> None:
            request_builders.cleanup_prepared_moss_tts_local_request(request_id)
            model.reset_request(request_id)

        return abort_request

    def extra_scheduler_kwargs(self) -> SchedulerExtras[MossTTSLocalSGLangRequestData]:
        return {
            "enable_async_decode": self.enable_async_decode,
            "async_decode_min_batch_size": self.async_decode_min_batch_size,
            "prefill_coalesce_requests": self.prefill_coalesce_requests,
            "prefill_coalesce_wait_ms": self.prefill_coalesce_wait_ms,
        }

    def post_scheduler_setup(
        self,
        scheduler: OmniScheduler[MossTTSLocalSGLangRequestData],
        model_runner: MossTTSLocalModelRunner,
    ) -> None:
        model_runner.set_stream_outbox(scheduler.outbox)
