"""SGLang-native MOSS-TTS Local (v1.5) model wrapper.

Architecture: a 36-layer Qwen3 global backbone consumes one summed embedding
per audio frame (text channel + 12 RVQ code channels); a 1-layer frame-local
transformer then decodes the next frame from the backbone's last hidden state
— a binary continue/stop decision followed by 12 sequentially sampled RVQ
codes, each fed back as the next local-position embedding.

The backbone runs under SGLang's scheduler (radix cache + CUDA graph); the
local transformer micro-loop runs batched in :meth:`decode_frame`, driven by
the model runner after each backbone step.
"""

from __future__ import annotations

import logging
import os
from typing import Callable, Iterable, Optional, Tuple

import torch
import torch.nn.functional as F
from sglang.srt.distributed import get_pp_group
from sglang.srt.layers.logits_processor import LogitsProcessorOutput
from sglang.srt.layers.quantization.base_config import QuantizationConfig
from sglang.srt.layers.utils import PPMissingLayer, get_layer_id
from sglang.srt.layers.vocab_parallel_embedding import VocabParallelEmbedding
from sglang.srt.model_executor.forward_batch_info import ForwardBatch, PPProxyTensors
from sglang.srt.model_loader.weight_utils import default_weight_loader
from sglang.srt.models.qwen3 import Qwen3Model
from sglang.srt.runtime_context import get_schedule
from sglang.srt.utils import add_prefix
from transformers import GPT2Config, PretrainedConfig, Qwen3Config

from sglang_omni.models.moss_tts.sampling_kernels import (
    MAX_FUSED_SAMPLE_VOCAB,
    sample_seeded_branchless,
    sample_seeded_fused,
)
from sglang_omni.models.moss_tts_local.local_transformer import MossTTSLocalTransformer
from sglang_omni.models.moss_tts_local.payload_types import (
    moss_tts_local_special_token_defaults,
)
from sglang_omni.models.moss_tts_local.state_pool import MossTTSLocalDecodeStatePool

logger = logging.getLogger(__name__)


def as_qwen3_config(
    config: PretrainedConfig | dict[str, object] | None,
) -> Qwen3Config | None:
    from transformers import Qwen3Config

    if isinstance(config, Qwen3Config):
        return config
    else:
        pass
    if isinstance(config, dict):
        return Qwen3Config(**config)
    else:
        pass
    if hasattr(config, "to_dict"):
        return Qwen3Config(**config.to_dict())
    else:
        pass
    return config


class MossTTSLocalSGLangModel(torch.nn.Module):
    """MOSS-TTS Local AR model: Qwen3 backbone + 1-layer local transformer."""

    packed_modules_mapping = {
        "qkv_proj": ["q_proj", "k_proj", "v_proj"],
        "gate_up_proj": ["gate_proj", "up_proj"],
    }

    def __init__(
        self,
        config: PretrainedConfig,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
    ) -> None:
        super().__init__()
        self.pp_group = get_pp_group()
        self.config = self.normalize_config(config)
        self.quant_config = quant_config
        self.hidden_size = int(self.config.hidden_size)
        self.n_vq = int(self.config.n_vq)
        self.embedding_list = torch.nn.ModuleList()
        if self.pp_group.is_first_rank:
            for idx in range(self.config.channels):
                self.embedding_list.append(
                    VocabParallelEmbedding(
                        int(self.config.vocab_size_list[idx]),
                        self.hidden_size,
                        quant_config=quant_config,
                        prefix=add_prefix(f"embedding_list.{idx}", prefix),
                    )
                )
        else:
            for _ in range(self.config.channels):
                self.embedding_list.append(PPMissingLayer())
        self.model = Qwen3Model(
            config=self.config.language_config,
            quant_config=quant_config,
            prefix=add_prefix("model", prefix),
        )
        gpt2_cfg = self.config.gpt2_config
        self.local_transformer = MossTTSLocalTransformer(
            hidden_size=self.hidden_size,
            num_heads=int(self.cfg_get(gpt2_cfg, "n_head", 32)),
            inner_size=int(self.cfg_get(gpt2_cfg, "n_inner", 4 * self.hidden_size)),
            num_layers=int(getattr(self.config, "local_transformer_layers", 1)),
            max_positions=self.n_vq + 1,
            rope_base=float(self.cfg_get(gpt2_cfg, "rope_base", 1000000.0)),
            layer_norm_eps=float(self.cfg_get(gpt2_cfg, "layer_norm_epsilon", 1e-06)),
        )
        self.local_text_lm_head = torch.nn.Linear(self.hidden_size, 2, bias=False)
        weight = self.first_embedding_weight()
        self.decode_input_embedding = torch.nn.Embedding(
            get_schedule().max_running_requests,
            self.hidden_size,
            device=weight.device,
            dtype=weight.dtype,
        )
        self.decode_input_embedding.weight.requires_grad_(False)
        self.state_pool = MossTTSLocalDecodeStatePool(self)
        self.compiled_frame_sampler: Callable[..., torch.Tensor] | None = None
        self.large_vocab_frame_sampler: Callable[..., torch.Tensor] | None = None
        self.frame_compile_configured = False

    def acquire_row(self, rid: str) -> int:
        """Assign (or return the existing) decode-state pool row for ``rid``."""
        return self.state_pool.acquire_row(rid)

    def release_row(self, rid: str) -> None:
        """Return ``rid``'s pool row to the free list. No-op if unheld."""
        self.state_pool.release_row(rid)

    def reset_request(self, rid: str) -> None:
        """Release pool state for a finished or aborted request (idempotent)."""
        self.state_pool.release_row(rid)

    def row_for(self, rid: str) -> int | None:
        """Return ``rid``'s pool row, or ``None`` if it holds none."""
        return self.state_pool.row_for(rid)

    @staticmethod
    def cfg_get(config: GPT2Config, name: str, default: int | float) -> object:
        if isinstance(config, dict):
            value = config.get(name, default)
        else:
            value = getattr(config, name, default)
        return default if value is None else value

    @staticmethod
    def normalize_config(config: PretrainedConfig) -> PretrainedConfig:
        qwen3_config = getattr(config, "qwen3_config", None)
        if qwen3_config is None:
            qwen3_config = getattr(config, "language_config", None)
        else:
            pass
        language_config = as_qwen3_config(qwen3_config)
        try:
            config.language_config = language_config
        except AttributeError:
            config.qwen3_config = language_config
        config.hidden_size = int(
            getattr(config, "hidden_size", None) or language_config.hidden_size
        )
        config.vocab_size = int(
            getattr(config, "vocab_size", None) or language_config.vocab_size
        )
        config.n_vq = int(getattr(config, "n_vq", 12))
        config.channels = int(getattr(config, "channels", config.n_vq + 1))
        audio_vocab_size = int(getattr(config, "audio_vocab_size", 1024) or 1024)
        config.audio_vocab_size = audio_vocab_size
        if not getattr(config, "vocab_size_list", None):
            config.vocab_size_list = [config.vocab_size] + [audio_vocab_size + 1] * (
                config.channels - 1
            )
        else:
            pass
        for attr, default in moss_tts_local_special_token_defaults(audio_vocab_size):
            if getattr(config, attr, None) is None:
                setattr(config, attr, default)
            else:
                pass
        if not getattr(config, "pad_token", None):
            text_pad = int(getattr(config, "pad_token_id", 0) or 0)
            audio_pad = int(config.audio_pad_code)
            config.pad_token = [text_pad] + [audio_pad] * (config.channels - 1)
        else:
            pass
        config.language_config.channels = config.channels
        config.language_config.vocab_size_list = list(config.vocab_size_list)
        config.language_config.pad_token = list(config.pad_token)
        return config

    def first_embedding_weight(self) -> torch.Tensor:
        for layer in self.embedding_list:
            weight = getattr(layer, "weight", None)
            if isinstance(weight, torch.Tensor):
                return weight
            else:
                pass
        return torch.empty((), dtype=torch.float32)

    @property
    def start_layer(self) -> int:
        return self.model.start_layer

    @property
    def end_layer(self) -> int:
        return self.model.end_layer

    @property
    def device(self) -> torch.device:
        return self.first_embedding_weight().device

    @property
    def dtype(self) -> torch.dtype:
        return self.first_embedding_weight().dtype

    def audio_embedding_weight(self, channel: int) -> torch.Tensor:
        """Rows 0..audio_vocab_size-1 of codebook ``channel``'s table."""
        weight = self.embedding_list[channel + 1].weight
        return weight[: int(self.config.audio_vocab_size)]

    def get_input_embeddings(self, input_ids: torch.Tensor) -> torch.Tensor:
        return self.prepare_multi_modal_inputs(input_ids)

    def prepare_multi_modal_inputs(self, input_ids: torch.Tensor) -> torch.Tensor:
        """Sum text + per-codebook embeddings for ``[T, channels]`` rows.

        Pad codes (``audio_pad_code``) hit the zeroed extra row of each audio
        table, matching the upstream zero-mask semantics without masking.
        """
        if input_ids.dim() == 1:
            channels = int(self.config.channels)
            total_tokens = int(input_ids.shape[0])
            if total_tokens % channels == 0:
                input_ids_2d = input_ids.view(total_tokens // channels, channels)
            else:
                input_ids_2d = torch.empty(
                    (total_tokens, channels),
                    dtype=input_ids.dtype,
                    device=input_ids.device,
                )
                pad_token = self.config.pad_token
                for idx in range(channels):
                    input_ids_2d[:, idx].fill_(int(pad_token[idx]))
                input_ids_2d[:, 0] = input_ids
        elif input_ids.dim() == 2:
            input_ids_2d = input_ids
        else:
            raise ValueError(
                f"MOSS-TTS Local input_ids must be rank-1 flattened rows or rank-2 multi-channel rows, got shape {tuple(input_ids.shape)}"
            )
        if int(input_ids_2d.shape[-1]) != int(self.config.channels):
            raise ValueError(
                f"MOSS-TTS Local expected {self.config.channels} channels, got {input_ids_2d.shape[-1]}"
            )
        else:
            pass
        weight = self.first_embedding_weight()
        embeds = torch.zeros(
            input_ids_2d.shape[0],
            self.hidden_size,
            device=input_ids_2d.device,
            dtype=weight.dtype,
        )
        for idx, embed_layer in enumerate(self.embedding_list):
            embeds = embeds + embed_layer(input_ids_2d[:, idx])
        return embeds

    @torch.no_grad()
    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        forward_batch: ForwardBatch,
        input_embeds: Optional[torch.Tensor] = None,
        pp_proxy_tensors: Optional[PPProxyTensors] = None,
        input_embeds_are_projected: bool = False,
    ) -> LogitsProcessorOutput:
        del input_embeds_are_projected
        if input_embeds is None:
            forward_mode = getattr(forward_batch, "forward_mode", None)
            is_decode = (
                forward_mode is not None
                and hasattr(forward_mode, "is_decode")
                and bool(forward_mode.is_decode())
            )
            if is_decode:
                input_embeds = self.decode_input_embedding(input_ids)
            elif self.pp_group.is_first_rank:
                input_embeds = self.prepare_multi_modal_inputs(input_ids)
            else:
                input_embeds = None
        else:
            pass
        hidden_states = self.model(
            input_ids=None,
            positions=positions,
            forward_batch=forward_batch,
            input_embeds=input_embeds,
            pp_proxy_tensors=pp_proxy_tensors,
        )
        if not self.pp_group.is_last_rank:
            return hidden_states
        else:
            pass
        sample_hidden_states = self.select_sample_hidden_states(
            hidden_states, forward_batch
        )
        dummy_logits = sample_hidden_states.new_empty(
            (sample_hidden_states.shape[0], 1)
        )
        return LogitsProcessorOutput(
            next_token_logits=dummy_logits, hidden_states=sample_hidden_states
        )

    @staticmethod
    def select_sample_hidden_states(
        hidden_states: torch.Tensor, forward_batch: ForwardBatch
    ) -> torch.Tensor:
        forward_mode = getattr(forward_batch, "forward_mode", None)
        is_extend = (
            forward_mode is not None
            and hasattr(forward_mode, "is_extend")
            and bool(forward_mode.is_extend())
        )
        if not is_extend:
            return hidden_states
        else:
            pass
        extend_seq_lens = getattr(forward_batch, "extend_seq_lens", None)
        if extend_seq_lens is None:
            return hidden_states[-1:].contiguous()
        else:
            pass
        last_index = (
            torch.cumsum(
                extend_seq_lens.to(device=hidden_states.device, dtype=torch.long), dim=0
            )
            - 1
        )
        return hidden_states[last_index]

    sample_seeded_branchless = staticmethod(sample_seeded_branchless)

    def ensure_frame_compile_config(self) -> None:
        if self.frame_compile_configured:
            return
        else:
            pass
        from sglang.srt.compilation.torch_compile_decoration import (
            set_torch_compile_config,
        )

        set_torch_compile_config()
        self.frame_compile_configured = True

    def compile_branchless_sampler(self):
        compile_mode = os.environ.get(
            "SGLANG_TORCH_COMPILE_MODE", "max-autotune-no-cudagraphs"
        )
        self.ensure_frame_compile_config()
        compiled = torch.compile(sample_seeded_branchless, mode=compile_mode)
        logger.info(f"Compiled MOSS-TTS Local frame sampler (mode={compile_mode})")
        return compiled

    def ensure_frame_sampler_compile(self) -> None:
        if self.compiled_frame_sampler is None:
            if os.environ.get("MOSS_LOCAL_FUSED_FRAME_SAMPLER", "1") != "0":
                self.compiled_frame_sampler = self.fused_or_branchless_sampler
                self.sample_seeded_branchless = self.fused_or_branchless_sampler
                logger.info("Using fused MOSS-TTS Local frame sampler")
                return
            else:
                pass
            self.compiled_frame_sampler = self.compile_branchless_sampler()
            self.sample_seeded_branchless = self.compiled_frame_sampler
        else:
            pass

    def fused_or_branchless_sampler(
        self, logits: torch.Tensor, **kwargs
    ) -> torch.Tensor:
        if logits.shape[-1] <= MAX_FUSED_SAMPLE_VOCAB:
            return sample_seeded_fused(logits, **kwargs)
        else:
            pass
        if self.large_vocab_frame_sampler is None:
            self.large_vocab_frame_sampler = self.compile_branchless_sampler()
        else:
            pass
        return self.large_vocab_frame_sampler(logits, **kwargs)

    @torch.no_grad()
    def decode_frame_graphable(
        self,
        hidden_states: torch.Tensor,
        text_temperature: torch.Tensor,
        text_top_p: torch.Tensor,
        text_top_k: torch.Tensor,
        audio_temperature: torch.Tensor,
        audio_top_p: torch.Tensor,
        audio_top_k: torch.Tensor,
        seeds: torch.Tensor,
        base_positions: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Branchless frame decode used both eagerly and under graph capture.

        ``base_positions`` is ``generation_steps * (n_vq + 1)``; channel
        ``c``'s sampling position is ``base_positions + c + 1`` and the binary
        text decision samples at ``base_positions``, matching the eager path.
        Repetition penalty is not supported here (the runner falls back to
        the eager path when a request enables it).

        Returns ``(stop_choice, codes, feedback_embeds)`` where
        ``feedback_embeds`` is the next backbone input embedding for a
        continuing row — the assistant-slot text embedding plus all 12 code
        embeddings, summed in the same channel order as
        ``_prepare_multi_modal_inputs``.
        """
        local_hidden = self.local_transformer.step(
            hidden_states.to(dtype=self.dtype), 0
        )
        text_logits = F.linear(local_hidden, self.local_text_lm_head.weight).float()
        stop_choice = self.sample_seeded_branchless(
            text_logits,
            temperature=text_temperature,
            top_p=text_top_p,
            top_k=text_top_k,
            seeds=seeds,
            positions=base_positions,
        )
        slot_ids = torch.full_like(
            seeds, int(self.config.audio_assistant_slot_token_id)
        )
        feedback = self.embedding_list[0](slot_ids)
        codes = []
        current = local_hidden
        for channel in range(self.n_vq):
            head_weight = self.audio_embedding_weight(channel)
            logits = F.linear(current, head_weight).float()
            code = self.sample_seeded_branchless(
                logits,
                temperature=audio_temperature,
                top_p=audio_top_p,
                top_k=audio_top_k,
                seeds=seeds,
                positions=base_positions + channel + 1,
            )
            codes.append(code)
            code_embed = F.embedding(code, head_weight)
            feedback = feedback + code_embed
            if channel + 1 < self.n_vq:
                current = self.local_transformer.step(
                    code_embed.to(dtype=self.dtype), channel + 1
                )
            else:
                pass
        return (stop_choice, torch.stack(codes, dim=-1), feedback)

    @torch.no_grad()
    def init_frame_decode_graphs(self, batch_sizes: list[int]) -> None:
        """Capture the per-frame local decode (1 + n_vq micro-steps plus all
        13 seeded sampling passes) into one CUDA graph per batch-size bucket.

        Eager execution launches ~500 kernels per frame (~22 ms regardless of
        batch size); replay collapses that to a few milliseconds. Must run
        during engine init while the device is otherwise idle.
        """
        buckets = sorted({int(bs) for bs in batch_sizes})
        if not buckets:
            return
        else:
            pass
        device = self.device
        max_eager_bs = int(self.decode_input_embedding.weight.shape[0])
        self.local_transformer.ensure_kv_cache(
            max(max(buckets), max_eager_bs), device, self.dtype
        )
        self.local_transformer.freeze_kv_cache()
        self.ensure_frame_sampler_compile()
        frame_decode = self.decode_frame_graphable
        self.frame_graphs: dict[
            int,
            tuple[
                torch.cuda.CUDAGraph,
                dict[str, torch.Tensor],
                torch.Tensor,
                torch.Tensor,
                torch.Tensor,
            ],
        ] = {}
        for bucket in buckets:
            static_inputs = {
                "hidden_states": torch.zeros(
                    bucket, self.hidden_size, device=device, dtype=self.dtype
                ),
                "text_temperature": torch.ones(
                    bucket, device=device, dtype=torch.float32
                ),
                "text_top_p": torch.ones(bucket, device=device, dtype=torch.float32),
                "text_top_k": torch.full(
                    (bucket,), 50, device=device, dtype=torch.long
                ),
                "audio_temperature": torch.ones(
                    bucket, device=device, dtype=torch.float32
                ),
                "audio_top_p": torch.ones(bucket, device=device, dtype=torch.float32),
                "audio_top_k": torch.full(
                    (bucket,), 25, device=device, dtype=torch.long
                ),
                "seeds": torch.zeros(bucket, device=device, dtype=torch.long),
                "base_positions": torch.zeros(bucket, device=device, dtype=torch.long),
            }
            warmup_stream = torch.cuda.Stream()
            warmup_stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(warmup_stream):
                for _ in range(2):
                    frame_decode(**static_inputs)
            torch.cuda.current_stream().wait_stream(warmup_stream)
            torch.cuda.synchronize()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                stop_choice, codes, feedback = frame_decode(**static_inputs)
            self.frame_graphs[bucket] = (
                graph,
                static_inputs,
                stop_choice,
                codes,
                feedback,
            )
        logger.info(
            f"MOSS-TTS Local frame-decode CUDA graphs captured for bs={buckets}"
        )

    @property
    def frame_graph_max_bs(self) -> int:
        graphs = getattr(self, "frame_graphs", None)
        return max(graphs) if graphs else 0

    @torch.no_grad()
    def decode_frame_graphed(
        self,
        hidden_states: torch.Tensor,
        *,
        text_temperature: torch.Tensor,
        text_top_p: torch.Tensor,
        text_top_k: torch.Tensor,
        audio_temperature: torch.Tensor,
        audio_top_p: torch.Tensor,
        audio_top_k: torch.Tensor,
        seeds: torch.Tensor,
        base_positions: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Replay the captured frame decode for this batch (padded up to the
        nearest bucket; padding rows sample garbage that the caller discards).

        The returned tensors are slices of the graph's static output buffers:
        the caller must copy anything it keeps before the next replay (any
        later prefill or decode step replays these graphs).
        """
        batch_size = hidden_states.shape[0]
        bucket = min((b for b in self.frame_graphs if b >= batch_size))
        graph, static_inputs, stop_choice, codes, feedback = self.frame_graphs[bucket]
        static_inputs["hidden_states"][:batch_size].copy_(
            hidden_states.to(dtype=self.dtype)
        )
        if batch_size < bucket:
            static_inputs["hidden_states"][batch_size:].zero_()
        else:
            pass
        for key, value in (
            ("text_temperature", text_temperature),
            ("text_top_p", text_top_p),
            ("text_top_k", text_top_k),
            ("audio_temperature", audio_temperature),
            ("audio_top_p", audio_top_p),
            ("audio_top_k", audio_top_k),
            ("seeds", seeds),
            ("base_positions", base_positions),
        ):
            buf = static_inputs[key]
            buf[:batch_size].copy_(value)
            if batch_size < bucket:
                buf[batch_size:].fill_(1 if buf.dtype.is_floating_point else 1)
            else:
                pass
        graph.replay()
        return (stop_choice[:batch_size], codes[:batch_size], feedback[:batch_size])

    @torch.no_grad()
    def decode_frame(
        self,
        hidden_states: torch.Tensor,
        *,
        sample_text: Callable[[torch.Tensor], torch.Tensor],
        sample_audio: Callable[[torch.Tensor, int], torch.Tensor],
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Decode one audio frame for the whole batch.

        Args:
            hidden_states: ``[batch, hidden]`` backbone last hidden states.
            sample_text: maps ``[batch, 2]`` fp32 binary-head logits to a
                ``[batch]`` long tensor of indices (0=continue, 1=stop).
            sample_audio: maps (``[batch, audio_vocab]`` fp32 logits, channel)
                to a ``[batch]`` long tensor of codes.

        Returns:
            ``(stop_choice [batch], codes [batch, n_vq])``. Codes are sampled
            for every row regardless of the stop choice; the runner discards
            frames of rows that chose stop, mirroring the upstream loop which
            never emits a frame alongside ``audio_end``.
        """
        local_hidden = self.local_transformer.step(
            hidden_states.to(dtype=self.dtype), 0
        )
        text_logits = F.linear(local_hidden, self.local_text_lm_head.weight)
        stop_choice = sample_text(text_logits.float())
        codes = []
        current = local_hidden
        for channel in range(self.n_vq):
            head_weight = self.audio_embedding_weight(channel)
            logits = F.linear(current, head_weight)
            code = sample_audio(logits.float(), channel)
            codes.append(code)
            if channel + 1 < self.n_vq:
                next_embed = F.embedding(code, head_weight)
                current = self.local_transformer.step(
                    next_embed.to(dtype=self.dtype), channel + 1
                )
            else:
                pass
        return (stop_choice, torch.stack(codes, dim=-1))

    def load_weights(self, weights: Iterable[Tuple[str, torch.Tensor]]) -> None:
        stacked_params_mapping = [
            ("qkv_proj", "q_proj", "q"),
            ("qkv_proj", "k_proj", "k"),
            ("qkv_proj", "v_proj", "v"),
            ("gate_up_proj", "gate_proj", 0),
            ("gate_up_proj", "up_proj", 1),
        ]
        params_dict = dict(self.named_parameters())
        for original_name, loaded_weight in weights:
            name = original_name
            if name.startswith("transformer."):
                name = "model." + name[len("transformer.") :]
            else:
                pass
            layer_id = get_layer_id(name)
            if (
                layer_id is not None
                and hasattr(self.model, "start_layer")
                and (
                    layer_id < self.model.start_layer
                    or layer_id >= self.model.end_layer
                )
            ):
                continue
            else:
                pass
            if "rotary_emb.inv_freq" in name:
                continue
            else:
                pass
            if name.startswith("text_lm_head.") or name.startswith("audio_lm_heads."):
                continue
            else:
                pass
            if name.startswith("audio_embeddings.") and name.endswith(".weight"):
                mapped = self.map_audio_embedding_name(name)
                if mapped is not None and mapped in params_dict:
                    param = params_dict[mapped]
                    rows = int(loaded_weight.shape[0])
                    with torch.no_grad():
                        param.data[:rows].copy_(
                            loaded_weight.to(device=param.device, dtype=param.dtype)
                        )
                else:
                    pass
                continue
            else:
                pass
            if name.startswith("local_transformer.") or name.startswith(
                "local_text_lm_head."
            ):
                param = params_dict.get(name)
                if param is not None:
                    self.load_param(param, loaded_weight)
                else:
                    logger.warning(
                        f"MOSS-TTS Local parameter {original_name} not found"
                    )
                continue
            else:
                pass
            if name == "model.embed_tokens.weight":
                mapped = "embedding_list.0.weight"
                if mapped in params_dict:
                    self.load_param(params_dict[mapped], loaded_weight)
                else:
                    pass
            else:
                pass
            mapped_stacked = False
            for param_name, weight_name, shard_id in stacked_params_mapping:
                if weight_name not in name:
                    continue
                else:
                    pass
                mapped_name = name.replace(weight_name, param_name)
                if mapped_name.endswith(".bias") and mapped_name not in params_dict:
                    mapped_stacked = True
                    break
                else:
                    pass
                param = params_dict.get(mapped_name)
                if param is None:
                    break
                else:
                    pass
                weight_loader = getattr(param, "weight_loader", default_weight_loader)
                weight_loader(param, loaded_weight, shard_id)
                mapped_stacked = True
                break
            if mapped_stacked:
                continue
            else:
                pass
            if name.endswith(".bias") and name not in params_dict:
                continue
            else:
                pass
            param = params_dict.get(name)
            if param is not None:
                self.load_param(param, loaded_weight)
            else:
                logger.warning(f"MOSS-TTS Local parameter {original_name} not found")
        self.zero_audio_pad_rows()

    def zero_audio_pad_rows(self) -> None:
        """Zero rows >= audio_vocab_size so pad codes embed to exactly zero."""
        audio_vocab_size = int(self.config.audio_vocab_size)
        with torch.no_grad():
            for layer in self.embedding_list[1:]:
                weight = getattr(layer, "weight", None)
                if (
                    isinstance(weight, torch.Tensor)
                    and weight.shape[0] > audio_vocab_size
                ):
                    weight[audio_vocab_size:].zero_()
                else:
                    pass

    @staticmethod
    def map_audio_embedding_name(name: str) -> str | None:
        try:
            idx = int(name.split(".")[1]) + 1
        except (IndexError, ValueError):
            return None
        return f"embedding_list.{idx}.weight"

    @staticmethod
    def load_param(param: torch.nn.Parameter, loaded_weight: torch.Tensor) -> None:
        weight_loader = getattr(param, "weight_loader", default_weight_loader)
        weight_loader(param, loaded_weight)

    def get_embed_and_head(
        self,
    ) -> tuple[list[torch.Tensor | None], list[torch.Tensor]]:
        embed_weights = [
            getattr(layer, "weight", None) for layer in self.embedding_list
        ]
        return (embed_weights, [self.local_text_lm_head.weight])

    def load_kv_cache_scales(self, quantization_param_path: str) -> None:
        self.model.load_kv_cache_scales(quantization_param_path)


EntryClass = MossTTSLocalSGLangModel
