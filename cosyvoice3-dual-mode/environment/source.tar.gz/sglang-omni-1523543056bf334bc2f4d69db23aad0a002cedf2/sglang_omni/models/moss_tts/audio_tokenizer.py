# SPDX-License-Identifier: Apache-2.0
"""MOSS-Audio-Tokenizer runtime."""

from __future__ import annotations

import json
import logging
import math
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from os import PathLike
from pathlib import Path
from types import SimpleNamespace
from typing import TypedDict

import torch
import torch.nn.functional as F
from torch import nn
from torch.nn.utils.parametrize import is_parametrized, remove_parametrizations
from typing_extensions import Unpack

from sglang_omni.models.moss_tts.attention import (
    AUTO_ATTENTION_BACKEND,
    PACKED_FLASH_ATTENTION_BACKEND,
    SDPA_ATTENTION_BACKEND,
    AttentionBackendResolution,
    LocalCausalFlashPlan,
    MossAudioTokenizerAttention,
    MossAudioTokenizerStreamingModule,
    MossPackedRopeCache,
    PositionIdsCache,
    StreamingExecutionContext,
    merge_attention_backend_resolutions,
    pack_padded_sequence,
    pack_padded_sequence_from_host_lengths,
    pack_unpadded_sequence,
    unpack_packed_sequence,
    unpack_packed_sequence_from_indices,
    unpack_unpadded_sequence,
    validate_attention_backend,
)
from sglang_omni.models.moss_tts.vocoder_quantizer import (
    MossAudioTokenizerQuantizerDecoder,
)
from sglang_omni.models.weight_loader import (
    load_module,
    load_weights_by_prefix,
    resolve_model_path,
)
from sglang_omni.utils.json import JsonValue

logger = logging.getLogger(__name__)


DEFAULT_MOSS_TTS_AUDIO_TOKENIZER = "OpenMOSS-Team/MOSS-Audio-Tokenizer"
DEFAULT_MOSS_TTS_LOCAL_AUDIO_TOKENIZER = "OpenMOSS-Team/MOSS-Audio-Tokenizer-v2"
_LOUDNESS_TARGET_DBFS = -20.0
_LOUDNESS_GAIN_MIN_DB = -3.0
_LOUDNESS_GAIN_MAX_DB = 3.0
# note (Zhang Yiyang): Reserve RoPE positions for 30 minutes of streaming
# audio. Each decoder stage uses its own frame rate to size the fixed table
# before CUDA graph capture, avoiding over-allocation in slower stages.
_STREAMING_ROPE_CACHE_DURATION_SECONDS = 30 * 60
_HF_FLASH_ATTENTION_IMPLEMENTATION = "flash_attention_2"
_SUPPORTED_ATTENTION_IMPLEMENTATIONS = (
    None,
    _HF_FLASH_ATTENTION_IMPLEMENTATION,
    SDPA_ATTENTION_BACKEND,
)


def resolve_moss_audio_attention_backend(
    attention_backend: str,
    attention_implementation: str | None,
) -> str:
    validate_attention_backend(attention_backend)
    if attention_implementation not in _SUPPORTED_ATTENTION_IMPLEMENTATIONS:
        raise ValueError(
            "attention_implementation must be None, 'flash_attention_2', "
            f"or 'sdpa'; got {attention_implementation!r}"
        )
    else:
        pass
    if attention_backend != AUTO_ATTENTION_BACKEND:
        return attention_backend
    else:
        pass
    if attention_implementation == SDPA_ATTENTION_BACKEND:
        return SDPA_ATTENTION_BACKEND
    else:
        pass
    return AUTO_ATTENTION_BACKEND


# Note (Zhang Yiyang): Prefer the runtime model value, then the canonical config
# field, and finally the legacy config alias for checkpoint compatibility.
def resolve_moss_audio_sample_rate(
    model: MossAudioTokenizerEncoder, config: SimpleNamespace
) -> int:
    for value in (
        getattr(model, "sampling_rate", None),
        getattr(config, "sampling_rate", None),
        getattr(config, "sample_rate", None),
    ):
        if value is not None:
            return int(value)
        else:
            pass
    raise ValueError(
        "MOSS-Audio-Tokenizer model/config lacks sampling_rate or sample_rate"
    )


def attention_backend_label(resolution: AttentionBackendResolution) -> str:
    if resolution.fallback_reason is None:
        return resolution.backend
    else:
        pass
    return f"{resolution.backend} (fallback: {resolution.fallback_reason})"


class MossAudioTokenizerV1FeedForward(nn.Module):
    """Expose MOSS-Audio-Tokenizer v1 Linear-GELU-Linear weights."""

    def __init__(
        self,
        linear1: nn.Module,
        linear2: nn.Module,
        activation: Callable[[torch.Tensor], torch.Tensor],
    ) -> None:
        super().__init__()
        self.linear1 = linear1
        self.linear2 = linear2
        self.activation = activation

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear2(self.activation(self.linear1(x)))


def feed_forward(module: nn.Module) -> nn.Module:
    ffn = getattr(module, "ffn", None)
    if ffn is not None:
        return ffn
    else:
        pass
    if (
        getattr(module, "linear1", None) is None
        or getattr(module, "linear2", None) is None
    ):
        raise ValueError("MOSS-Audio-Tokenizer transformer layer has no supported FFN")
    else:
        pass
    return MossAudioTokenizerV1FeedForward(
        module.linear1,
        module.linear2,
        module.activation,
    )


class PackedAttentionKwargs(TypedDict, total=False):
    cu_seqlens: torch.Tensor | None
    max_seqlen: int | None
    position_ids: torch.Tensor | None
    local_flash_plan: LocalCausalFlashPlan | None


class AttentionKwargs(PackedAttentionKwargs, total=False):
    input_lengths: torch.Tensor | None
    execution_context: StreamingExecutionContext | None


class MossAudioTokenizerTransformerLayer(nn.Module):
    """One shared MOSS-Audio-Tokenizer transformer layer."""

    def __init__(
        self,
        config: Mapping[str, object] | None = None,
        *,
        context: int | None = None,
        rope: nn.Module | None = None,
        moss_audio_tokenizer_v1_weights: bool = False,
        device: str | torch.device | None = None,
        dtype: torch.dtype | None = None,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
        packed_rope_cache: MossPackedRopeCache | None = None,
        source_module: nn.Module | None = None,
    ) -> None:
        super().__init__()
        if source_module is not None:
            if config is not None:
                raise ValueError(
                    "MOSS-Audio-Tokenizer transformer layer accepts either "
                    "config or source_module, not both"
                )
            else:
                pass
            norm1 = source_module.norm1
            selected_attention_backend = resolve_moss_audio_attention_backend(
                attention_backend,
                getattr(source_module.self_attn, "attention_implementation", None),
            )
            self_attn = MossAudioTokenizerAttention.from_module(
                source_module.self_attn,
                attention_backend=selected_attention_backend,
                packed_rope_cache=packed_rope_cache,
            )
            layer_scale_1 = source_module.layer_scale_1
            norm2 = source_module.norm2
            ffn = feed_forward(source_module)
            layer_scale_2 = source_module.layer_scale_2
        elif config is not None:
            d_model = int(config["d_model"])
            num_heads = int(config["num_heads"])
            dim_feedforward = int(config.get("dim_feedforward", 2048))
            causal = bool(config.get("causal", False))
            norm = str(config.get("norm", "layer_norm"))
            layer_scale = config.get("layer_scale")
            gating = str(config.get("gating", "none"))
            if gating != "none":
                raise ValueError(
                    "repository-local MOSS encoder currently supports gating='none'; "
                    f"got {gating!r}"
                )
            else:
                pass
            if moss_audio_tokenizer_v1_weights:
                ffn = MossAudioTokenizerV1FeedForward(
                    nn.Linear(
                        d_model,
                        dim_feedforward,
                        bias=False,
                        device=device,
                        dtype=dtype,
                    ),
                    nn.Linear(
                        dim_feedforward,
                        d_model,
                        bias=False,
                        device=device,
                        dtype=dtype,
                    ),
                    nn.GELU(),
                )
            else:
                ffn = nn.Sequential(
                    nn.Linear(
                        d_model,
                        dim_feedforward,
                        bias=False,
                        device=device,
                        dtype=dtype,
                    ),
                    nn.GELU(),
                    nn.Linear(
                        dim_feedforward,
                        d_model,
                        bias=False,
                        device=device,
                        dtype=dtype,
                    ),
                )
            if layer_scale is None:
                layer_scale_1 = nn.Identity()
                layer_scale_2 = nn.Identity()
            else:
                layer_scale_1 = LayerScale(
                    d_model,
                    init=float(layer_scale),
                    device=device,
                    dtype=dtype,
                )
                layer_scale_2 = LayerScale(
                    d_model,
                    init=float(layer_scale),
                    device=device,
                    dtype=dtype,
                )
            selected_attention_backend = resolve_moss_audio_attention_backend(
                attention_backend,
                (
                    None
                    if moss_audio_tokenizer_v1_weights
                    else config.get(
                        "attention_implementation",
                        _HF_FLASH_ATTENTION_IMPLEMENTATION,
                    )
                ),
            )
            self_attn = MossAudioTokenizerAttention(
                in_proj=nn.Linear(
                    d_model,
                    3 * d_model,
                    bias=False,
                    device=device,
                    dtype=dtype,
                ),
                out_proj=nn.Linear(
                    d_model,
                    d_model,
                    bias=False,
                    device=device,
                    dtype=dtype,
                ),
                embed_dim=d_model,
                num_heads=num_heads,
                causal=causal,
                context=context,
                rope=rope,
                attention_backend=selected_attention_backend,
                packed_rope_cache=packed_rope_cache,
            )
            norm1 = create_norm(norm, d_model, device=device, dtype=dtype)
            norm2 = create_norm(norm, d_model, device=device, dtype=dtype)
        else:
            raise ValueError(
                "MOSS-Audio-Tokenizer transformer layer requires config or "
                "source_module"
            )
        self.norm1 = norm1
        self.self_attn = self_attn
        self.layer_scale_1 = layer_scale_1
        self.norm2 = norm2
        self.ffn = ffn
        self.layer_scale_2 = layer_scale_2
        assert callable(self.ffn), "MOSS-Audio-Tokenizer layer requires an FFN"

    @classmethod
    def from_module(
        cls,
        module: nn.Module,
        *,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
        packed_rope_cache: MossPackedRopeCache | None = None,
    ) -> MossAudioTokenizerTransformerLayer:
        return cls(
            source_module=module,
            attention_backend=attention_backend,
            packed_rope_cache=packed_rope_cache,
        )

    def forward(
        self, x: torch.Tensor, **kwargs: Unpack[AttentionKwargs]
    ) -> torch.Tensor:
        residual = x
        x = self.norm1(x)
        x = residual.to(x) + self.layer_scale_1(self.self_attn(x, **kwargs))
        residual = x
        x = self.norm2(x)
        x = residual.to(x) + self.layer_scale_2(self.ffn(x))
        return x


class MossAudioTokenizerTransformer(MossAudioTokenizerStreamingModule):
    """Shared MOSS-Audio-Tokenizer transformer body."""

    def __init__(
        self,
        config: Mapping[str, object] | None = None,
        *,
        context: int | None = None,
        moss_audio_tokenizer_v1_weights: bool = False,
        device: str | torch.device | None = None,
        dtype: torch.dtype | None = None,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
        source_module: nn.Module | None = None,
    ) -> None:
        super().__init__()
        if source_module is not None:
            if config is not None:
                raise ValueError(
                    "MOSS-Audio-Tokenizer transformer accepts either config or "
                    "source_module, not both"
                )
            else:
                pass
            max_period = float(source_module.max_period)
            packed_rope_cache = MossPackedRopeCache(max_period=max_period)
            if isinstance(source_module, MossAudioTokenizerTransformer):
                packed_rope_cache.streaming_max_positions = (
                    source_module.packed_rope_cache.streaming_max_positions
                )
            else:
                pass
            layers = [
                MossAudioTokenizerTransformerLayer.from_module(
                    layer,
                    attention_backend=attention_backend,
                    packed_rope_cache=packed_rope_cache,
                )
                for layer in source_module.layers
            ]
            positional_embedding = source_module.positional_embedding
            positional_scale = float(source_module.positional_scale)
        elif config is not None:
            positional_embedding = str(config.get("positional_embedding", "sin"))
            max_period = float(config.get("max_period", 10_000))
            positional_scale = float(config.get("positional_scale", 1.0))
            rope = (
                RotaryEmbedding(max_period)
                if positional_embedding in {"rope", "sin_rope"}
                else None
            )
            packed_rope_cache = MossPackedRopeCache(max_period=max_period)
            layers = [
                MossAudioTokenizerTransformerLayer(
                    config,
                    context=context,
                    rope=rope,
                    moss_audio_tokenizer_v1_weights=moss_audio_tokenizer_v1_weights,
                    device=device,
                    dtype=dtype,
                    attention_backend=attention_backend,
                    packed_rope_cache=packed_rope_cache,
                )
                for _ in range(int(config["num_layers"]))
            ]
        else:
            raise ValueError(
                "MOSS-Audio-Tokenizer transformer requires config or source_module"
            )
        self.layers = nn.ModuleList(layers)
        self.packed_rope_cache = packed_rope_cache
        self.positional_embedding = positional_embedding
        self.positional_scale = float(positional_scale)
        self.max_period = float(max_period)

    @classmethod
    def from_module(
        cls,
        module: nn.Module,
        *,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
    ) -> MossAudioTokenizerTransformer:
        return cls(
            source_module=module,
            attention_backend=attention_backend,
        )

    def resolve_attention_backend(
        self,
        device: torch.device,
        dtype: torch.dtype | None,
    ) -> AttentionBackendResolution:
        return merge_attention_backend_resolutions(
            [
                layer.self_attn.resolve_attention_backend(device, dtype)
                for layer in self.layers
            ]
        )

    def supports_packed_attention(
        self,
        device: torch.device,
        dtype: torch.dtype | None,
    ) -> bool:
        return bool(self.layers) and all(
            layer.self_attn.supports_packed_attention(device, dtype)
            for layer in self.layers
        )

    def forward(
        self,
        x: torch.Tensor,
        **kwargs: Unpack[AttentionKwargs],
    ) -> torch.Tensor:
        execution_context = kwargs.pop("execution_context", None)
        state = self.streaming_state
        if state is None and execution_context is not None:
            raise RuntimeError(
                "streaming execution context requires an active transformer state"
            )
        else:
            pass
        if self.positional_embedding in {"sin", "sin_rope"}:
            if state is not None:
                raise ValueError(
                    "sinusoidal position embeddings are only supported "
                    "for non-streaming inputs"
                )
            else:
                pass
            if x.dim() == 3:
                positions = torch.arange(x.shape[1], device=x.device).view(1, -1)
            else:
                positions = kwargs.get("position_ids")
                if positions is None:
                    raise ValueError(
                        "packed transformer inputs require position_ids for "
                        "sinusoidal embeddings"
                    )
                else:
                    pass
            pos_emb = create_sin_embedding(
                positions,
                x.shape[-1],
                max_period=self.max_period,
                dtype=x.dtype,
            )
            x = x + self.positional_scale * pos_emb
        else:
            pass
        for layer in self.layers:
            x = layer(x, execution_context=execution_context, **kwargs)
        if state is not None and x.dim() != 3:
            raise ValueError("streaming transformer requires dense inputs")
        else:
            pass
        return x


class MossAudioTokenizerProjectedTransformer(nn.Module):
    """Shared projected Transformer stage with the MOSS-Audio-Tokenizer tensor layout."""

    def __init__(
        self,
        config: Mapping[str, object] | None = None,
        *,
        context: int | None = None,
        moss_audio_tokenizer_v1_weights: bool = False,
        device: str | torch.device | None = None,
        dtype: torch.dtype | None = None,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
        source_module: nn.Module | None = None,
    ) -> None:
        super().__init__()
        if source_module is not None:
            if config is not None:
                raise ValueError(
                    "MOSS-Audio-Tokenizer projected Transformer accepts either "
                    "config or source_module, not both"
                )
            else:
                pass
            input_proj = source_module.input_proj
            transformer = MossAudioTokenizerTransformer.from_module(
                source_module.transformer,
                attention_backend=attention_backend,
            )
            output_proj = source_module.output_proj
        elif config is not None:
            input_dimension = int(config["input_dimension"])
            output_dimension = int(config["output_dimension"])
            d_model = int(config["d_model"])
            input_proj = (
                nn.Linear(
                    input_dimension,
                    d_model,
                    bias=False,
                    device=device,
                    dtype=dtype,
                )
                if not moss_audio_tokenizer_v1_weights or input_dimension != d_model
                else nn.Identity()
            )
            output_proj = (
                nn.Linear(
                    d_model,
                    output_dimension,
                    bias=False,
                    device=device,
                    dtype=dtype,
                )
                if not moss_audio_tokenizer_v1_weights or d_model != output_dimension
                else nn.Identity()
            )
            transformer = MossAudioTokenizerTransformer(
                config,
                context=context,
                moss_audio_tokenizer_v1_weights=moss_audio_tokenizer_v1_weights,
                device=device,
                dtype=dtype,
                attention_backend=attention_backend,
            )
        else:
            raise ValueError(
                "MOSS-Audio-Tokenizer projected Transformer requires config or "
                "source_module"
            )
        self.module_type = "Transformer"
        self.downsample_ratio = 1
        self.input_proj = input_proj
        self.transformer = transformer
        self.output_proj = output_proj
        self.position_ids_cache = PositionIdsCache()

    @property
    def is_streaming(self) -> bool:
        return self.transformer.is_streaming

    @classmethod
    def from_module(
        cls,
        module: nn.Module,
        *,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
    ) -> MossAudioTokenizerProjectedTransformer:
        return cls(
            source_module=module,
            attention_backend=attention_backend,
        )

    def forward(
        self,
        x: torch.Tensor,
        input_lengths: torch.Tensor,
        *,
        input_lengths_cpu: Sequence[int] | None = None,
        execution_context: StreamingExecutionContext | None = None,
        **kwargs: Unpack[PackedAttentionKwargs],
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if execution_context is not None and not self.is_streaming:
            raise RuntimeError(
                "streaming execution context requires an active projected transformer"
            )
        else:
            pass
        x = self.input_proj(x.transpose(1, 2))
        backend = None
        if not self.is_streaming:
            backend = self.transformer.resolve_attention_backend(
                x.device,
                MossAudioTokenizerAttention.get_backend_dtype(x),
            ).backend
        else:
            pass
        if backend == PACKED_FLASH_ATTENTION_BACKEND:
            batch_size, max_seqlen, _ = x.shape
            if input_lengths_cpu is not None:
                if len(input_lengths_cpu) != batch_size:
                    raise ValueError(
                        "input_lengths_cpu must match the decoder batch size"
                    )
                else:
                    pass
                max_valid_seqlen = max(map(int, input_lengths_cpu), default=0)
            else:
                max_valid_seqlen = int(input_lengths.max().item()) if max_seqlen else 0
            if max_valid_seqlen == 0:
                x = x.new_zeros(x.shape)
            else:
                is_unpadded_single = batch_size == 1 and max_valid_seqlen == max_seqlen
                if is_unpadded_single:
                    packed_x, cu_seqlens, position_ids = pack_unpadded_sequence(
                        x,
                        self.position_ids_cache,
                    )
                    valid_mask = None
                    flat_indices = None
                elif input_lengths_cpu is not None:
                    packed_x, flat_indices, cu_seqlens, position_ids = (
                        pack_padded_sequence_from_host_lengths(
                            x,
                            input_lengths,
                            input_lengths_cpu,
                        )
                    )
                    valid_mask = None
                else:
                    packed_x, valid_mask, cu_seqlens, position_ids = (
                        pack_padded_sequence(x, input_lengths)
                    )
                    flat_indices = None
                first_attention = self.transformer.layers[0].self_attn
                local_flash_plan = first_attention.build_local_causal_flash_plan(
                    cu_seqlens,
                    max_seqlen=max_valid_seqlen,
                    sequence_lengths=input_lengths_cpu,
                )
                packed_x = self.transformer(
                    packed_x,
                    cu_seqlens=cu_seqlens,
                    max_seqlen=max_valid_seqlen,
                    position_ids=position_ids,
                    input_lengths=input_lengths,
                    local_flash_plan=local_flash_plan,
                    **kwargs,
                )
                if is_unpadded_single:
                    x = unpack_unpadded_sequence(packed_x)
                elif flat_indices is not None:
                    x = unpack_packed_sequence_from_indices(
                        packed_x,
                        flat_indices,
                        batch_size,
                        max_seqlen,
                    )
                else:
                    assert valid_mask is not None
                    x = unpack_packed_sequence(
                        packed_x,
                        valid_mask,
                        batch_size,
                        max_seqlen,
                    )
        else:
            x = self.transformer(
                x,
                input_lengths=input_lengths,
                execution_context=execution_context,
                **kwargs,
            )
        return self.output_proj(x).transpose(1, 2), input_lengths

    def supports_packed_attention(
        self,
        device: torch.device,
        dtype: torch.dtype | None,
    ) -> bool:
        return self.transformer.supports_packed_attention(device, dtype)

    def resolve_attention_backend(
        self,
        device: str | torch.device,
        dtype: torch.dtype | None,
    ) -> AttentionBackendResolution:
        return self.transformer.resolve_attention_backend(torch.device(device), dtype)


def update_decoder_cpu_lengths(
    stage: nn.Module,
    input_lengths: Sequence[int],
) -> list[int]:
    if isinstance(stage, MossAudioTokenizerProjectedTransformer):
        return list(map(int, input_lengths))
    else:
        pass
    patch_size = int(getattr(stage, "patch_size", 0))
    if patch_size <= 0:
        raise ValueError(
            "MOSS-Audio-Tokenizer patched pretransform requires patch_size > 0"
        )
    else:
        pass
    if bool(getattr(stage, "is_downsample", False)):
        return [int(length) // patch_size for length in input_lengths]
    else:
        pass
    return [int(length) * patch_size for length in input_lengths]


# note (Zhang Yiyang): Keep one non-streaming decoder stage container for both
# repository-owned and source decoder modules.


class MossAudioTokenizerVocoderDecoder(nn.ModuleList):
    """MOSS-Audio-Tokenizer vocoder decoder stage container."""

    def __init__(
        self,
        config: Mapping[str, object] | None = None,
        *,
        moss_audio_tokenizer_v1_weights: bool = False,
        device: str | torch.device | None = None,
        dtype: torch.dtype | None = None,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
        source_decoder: nn.Module | None = None,
    ) -> None:
        super().__init__()
        if source_decoder is not None:
            if config is not None:
                raise ValueError(
                    "MOSS-Audio-Tokenizer vocoder decoder accepts either config "
                    "or source_decoder, not both"
                )
            else:
                pass
            stages = []
            for stage in source_decoder:
                module_type = getattr(stage, "module_type", None)
                if module_type == "Transformer":
                    stage = MossAudioTokenizerProjectedTransformer.from_module(
                        stage,
                        attention_backend=attention_backend,
                    )
                elif module_type != "PatchedPretransform":
                    raise ValueError(
                        f"unsupported MOSS-Audio-Tokenizer vocoder decoder stage "
                        f"{stage.__class__.__name__} with module_type={module_type!r}"
                    )
                else:
                    pass
                stages.append(stage)
        elif config is not None:
            sampling_rate = config.get("sampling_rate") or config.get("sample_rate")
            if sampling_rate is None:
                raise ValueError("MOSS-Audio-Tokenizer config lacks sampling_rate")
            else:
                pass
            downsample_rate = int(config["downsample_rate"])
            default_context_duration = float(
                config.get("causal_transformer_context_duration", 10.0)
            )
            frame_rate = float(sampling_rate) / downsample_rate
            stages = []
            for stage_config_raw in config["decoder_kwargs"]:
                stage_config = dict(stage_config_raw)
                module_type = stage_config["module_type"]
                if module_type == "PatchedPretransform":
                    stage = PatchedPretransform(
                        int(stage_config["patch_size"]),
                        is_downsample=False,
                    )
                elif module_type == "Transformer":
                    stage_config.setdefault(
                        "attention_implementation",
                        config.get(
                            "attention_implementation",
                            _HF_FLASH_ATTENTION_IMPLEMENTATION,
                        ),
                    )
                    context_duration = float(
                        stage_config.pop("context_duration", default_context_duration)
                    )
                    stage = MossAudioTokenizerProjectedTransformer(
                        stage_config,
                        context=int(round(frame_rate * context_duration)),
                        moss_audio_tokenizer_v1_weights=(
                            moss_audio_tokenizer_v1_weights
                        ),
                        device=device,
                        dtype=dtype,
                        attention_backend=attention_backend,
                    )
                    stage.transformer.packed_rope_cache.streaming_max_positions = (
                        math.ceil(frame_rate * _STREAMING_ROPE_CACHE_DURATION_SECONDS)
                    )
                else:
                    raise ValueError(
                        "unsupported MOSS-Audio-Tokenizer decoder stage: "
                        f"{module_type!r}"
                    )
                stages.append(stage)
                if isinstance(stage, PatchedPretransform):
                    frame_rate *= stage.patch_size
                else:
                    pass
        else:
            raise ValueError(
                "MOSS-Audio-Tokenizer vocoder decoder requires config or source_decoder"
            )
        stages = list(stages)
        if not stages:
            raise ValueError(
                "MOSS-Audio-Tokenizer vocoder decoder must be a non-empty stage list"
            )
        else:
            pass
        self.attention_backend = validate_attention_backend(attention_backend)
        self.extend(stages)

    @classmethod
    def from_module(
        cls,
        decoder: nn.Module,
        *,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
    ) -> MossAudioTokenizerVocoderDecoder:
        if isinstance(decoder, cls):
            return decoder
        else:
            pass
        return cls(
            source_decoder=decoder,
            attention_backend=attention_backend,
        )

    def supports_packed_attention(
        self,
        device: str | torch.device,
        dtype: torch.dtype | None,
    ) -> bool:
        device = torch.device(device)
        transformer_stages = tuple(
            stage
            for stage in self
            if isinstance(stage, MossAudioTokenizerProjectedTransformer)
        )
        return bool(transformer_stages) and all(
            stage.supports_packed_attention(device, dtype)
            for stage in transformer_stages
        )

    def resolve_attention_backend(
        self,
        device: str | torch.device,
        dtype: torch.dtype | None,
    ) -> AttentionBackendResolution:
        device = torch.device(device)
        return merge_attention_backend_resolutions(
            [
                stage.resolve_attention_backend(device, dtype)
                for stage in self
                if isinstance(stage, MossAudioTokenizerProjectedTransformer)
            ]
        )

    def output_lengths(self, input_lengths: Sequence[int]) -> list[int]:
        output_lengths = list(map(int, input_lengths))
        for stage in self:
            output_lengths = update_decoder_cpu_lengths(stage, output_lengths)
        return output_lengths

    def forward(
        self,
        x: torch.Tensor,
        input_lengths: torch.Tensor,
        *,
        input_lengths_cpu: Sequence[int] | None = None,
        execution_context: StreamingExecutionContext | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        cpu_lengths = (
            None if input_lengths_cpu is None else list(map(int, input_lengths_cpu))
        )
        for stage in self:
            if isinstance(stage, MossAudioTokenizerProjectedTransformer):
                x, input_lengths = stage(
                    x,
                    input_lengths,
                    input_lengths_cpu=cpu_lengths,
                    execution_context=execution_context,
                )
            else:
                x, input_lengths = stage(x, input_lengths)
            if cpu_lengths is not None:
                cpu_lengths = update_decoder_cpu_lengths(stage, cpu_lengths)
            else:
                pass
        return x, input_lengths


def create_sin_embedding(
    positions: torch.Tensor,
    dim: int,
    *,
    max_period: float = 10_000,
    dtype: torch.dtype = torch.float32,
) -> torch.Tensor:
    """Create the sinusoidal embedding expected by the shared stage wrapper."""

    if dim % 2:
        raise ValueError(f"sinusoidal embedding requires an even dim, got {dim}")
    else:
        pass
    half_dim = dim // 2
    if half_dim <= 1:
        raise ValueError(f"sinusoidal embedding requires dim >= 4, got {dim}")
    else:
        pass
    positions = positions.to(dtype).unsqueeze(-1)
    dimensions = torch.arange(half_dim, device=positions.device, dtype=dtype)
    period = torch.full(
        (),
        float(max_period),
        device=positions.device,
        dtype=dtype,
    )
    phase = positions / (period ** (dimensions / (half_dim - 1)))
    return torch.cat((torch.cos(phase), torch.sin(phase)), dim=-1)


_AUDIO_DTYPES: dict[str, torch.dtype] = {
    "float32": torch.float32,
    "bfloat16": torch.bfloat16,
}


def resolve_moss_audio_dtype(
    dtype: str | torch.dtype | None,
    *,
    name: str,
    allow_none: bool,
) -> torch.dtype | None:
    if dtype is None:
        if allow_none:
            return None
        else:
            pass
    elif isinstance(dtype, str):
        resolved = _AUDIO_DTYPES.get(dtype.lower())
        if resolved is not None:
            return resolved
        else:
            pass
    elif isinstance(dtype, torch.dtype) and dtype in _AUDIO_DTYPES.values():
        return dtype
    else:
        pass
    allowed = "float32, bfloat16"
    if allow_none:
        allowed += ", or null"
    else:
        pass
    raise ValueError(f"{name} must be {allowed}; got {dtype!r}")


def validate_audio_dtypes(
    *,
    component_dtype: torch.dtype,
    component_name: str,
    compute_dtype: torch.dtype | None,
) -> None:
    if component_dtype not in (torch.float32, torch.bfloat16):
        raise ValueError(
            f"{component_name} must be torch.float32 or torch.bfloat16; "
            f"got {component_dtype!r}"
        )
    else:
        pass
    if compute_dtype not in (None, torch.float32, torch.bfloat16):
        raise ValueError(
            "compute_dtype must be torch.float32, torch.bfloat16, or None; "
            f"got {compute_dtype!r}"
        )
    else:
        pass


@dataclass
class MossAudioTokenizerEncoderOutput:
    """Output contract shared with the upstream audio-tokenizer encoder."""

    audio_codes: torch.Tensor
    audio_codes_lengths: torch.Tensor
    encoder_hidden_states: torch.Tensor


class LayerScale(nn.Module):
    def __init__(
        self,
        channels: int,
        *,
        init: float,
        device: str | torch.device | None,
        dtype: torch.dtype | None,
    ) -> None:
        super().__init__()
        self.scale = nn.Parameter(
            torch.full((channels,), init, device=device, dtype=dtype)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.scale * x


class RMSNorm(nn.Module):
    def __init__(
        self,
        dim: int,
        *,
        eps: float,
        device: str | torch.device | None,
        dtype: torch.dtype | None,
        compute_dtype: torch.dtype | None = None,
    ) -> None:
        super().__init__()
        self.eps = float(eps)
        self.compute_dtype = compute_dtype
        self.alpha = nn.Parameter(torch.ones((1, 1, dim), device=device, dtype=dtype))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        output_dtype = x.dtype
        if self.compute_dtype is not None:
            x = x.to(self.compute_dtype)
        else:
            pass
        variance = self.eps + torch.mean(x**2, dim=-1, keepdim=True)
        alpha = self.alpha.to(variance)
        if x.dim() == 2:
            alpha = alpha.view(1, -1)
        else:
            pass
        return (x * (alpha * torch.rsqrt(variance))).to(output_dtype)


def create_norm(
    norm: str,
    dim: int,
    *,
    device: str | torch.device | None,
    dtype: torch.dtype | None,
) -> nn.Module:
    if norm == "layer_norm":
        return nn.LayerNorm(dim, eps=1e-5, device=device, dtype=dtype)
    else:
        pass
    if norm == "rms_norm":
        return RMSNorm(dim, eps=1e-5, device=device, dtype=dtype)
    else:
        pass
    if norm == "rms_norm_f32":
        return RMSNorm(
            dim,
            eps=1e-8,
            device=device,
            # note (Zhang Yiyang): This norm explicitly computes in FP32. Keep
            # its scale in FP32 as well so the forward path does not recast the
            # parameter every call.
            dtype=torch.float32,
            compute_dtype=torch.float32,
        )
    else:
        pass
    raise ValueError(f"unsupported MOSS-Audio-Tokenizer norm: {norm!r}")


def restore_fp32_compute_parameters(module: nn.Module) -> None:
    """Keep parameters of explicitly FP32 compute modules in FP32."""
    for submodule in module.modules():
        if not isinstance(submodule, RMSNorm):
            continue
        else:
            pass
        if submodule.compute_dtype is not torch.float32:
            continue
        else:
            pass
        with torch.no_grad():
            submodule.alpha.data = submodule.alpha.data.to(dtype=torch.float32)


class RotaryEmbedding(nn.Module):
    def __init__(self, max_period: float) -> None:
        super().__init__()
        self.max_period = float(max_period)

    def forward(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        offset: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        batch_size, _, sequence_length, head_dim = q.shape
        frequencies = torch.exp(
            torch.arange(
                head_dim // 2,
                device=q.device,
                dtype=torch.float32,
            )
            * (-math.log(self.max_period) * 2 / head_dim)
        )
        positions = offset.float().view(batch_size, 1, 1, 1) + torch.arange(
            sequence_length,
            device=q.device,
            dtype=torch.float32,
        ).view(1, 1, sequence_length, 1)
        phase = positions * frequencies.view(1, 1, 1, -1)
        cos = torch.cos(phase)
        sin = torch.sin(phase)

        def rotate(x: torch.Tensor) -> torch.Tensor:
            shape = x.shape
            pairs = x.float().view(*shape[:-1], head_dim // 2, 2)
            real, imag = pairs[..., 0], pairs[..., 1]
            return (
                torch.stack(
                    (real * cos - imag * sin, real * sin + imag * cos),
                    dim=-1,
                )
                .to(x.dtype)
                .view(shape)
            )

        return rotate(q), rotate(k)


class PatchedPretransform(nn.Module):
    def __init__(self, patch_size: int, *, is_downsample: bool) -> None:
        super().__init__()
        self.module_type = "PatchedPretransform"
        self.patch_size = int(patch_size)
        self.downsample_ratio = self.patch_size
        self.is_downsample = bool(is_downsample)

    def forward(
        self,
        x: torch.Tensor,
        input_lengths: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        batch_size, channels, length = x.shape
        if self.is_downsample:
            x = (
                x.reshape(batch_size, channels, -1, self.patch_size)
                .permute(0, 1, 3, 2)
                .reshape(batch_size, channels * self.patch_size, -1)
            )
            return x, input_lengths // self.patch_size
        else:
            pass
        if channels % self.patch_size:
            raise ValueError(
                "MOSS-Audio-Tokenizer vocoder patch stage requires channels divisible by "
                f"patch_size, got channels={channels}, patch_size={self.patch_size}"
            )
        else:
            pass
        output_channels = channels // self.patch_size
        x = (
            x.reshape(batch_size, output_channels, self.patch_size, length)
            .permute(0, 1, 3, 2)
            .reshape(batch_size, output_channels, length * self.patch_size)
        )
        return x, input_lengths * self.patch_size


class LFQ(nn.Module):
    def __init__(
        self,
        *,
        input_dim: int,
        codebook_size: int,
        codebook_dim: int,
        device: str | torch.device | None,
    ) -> None:
        super().__init__()
        self.in_proj = (
            nn.utils.parametrizations.weight_norm(
                nn.Conv1d(
                    input_dim,
                    codebook_dim,
                    kernel_size=1,
                    device=device,
                    dtype=torch.float32,
                )
            )
            if input_dim != codebook_dim
            else nn.Identity()
        )
        self.out_proj = (
            nn.utils.parametrizations.weight_norm(
                nn.Conv1d(
                    codebook_dim,
                    input_dim,
                    kernel_size=1,
                    device=device,
                    dtype=torch.float32,
                )
            )
            if input_dim != codebook_dim
            else nn.Identity()
        )
        self.codebook = nn.Embedding(
            codebook_size,
            codebook_dim,
            device=device,
            dtype=torch.float32,
        )

    def forward(
        self,
        z: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        encoded = self.in_proj(z.float()).float()
        flat = F.normalize(encoded.transpose(1, 2).reshape(-1, encoded.shape[1]))
        codebook = F.normalize(self.codebook.weight.float())
        distance = (
            flat.pow(2).sum(1, keepdim=True)
            - 2 * flat @ codebook.t()
            + codebook.pow(2).sum(1, keepdim=True).t()
        )
        indices = (-distance).max(1)[1].reshape(z.shape[0], -1)
        quantized = F.embedding(indices, self.codebook.weight).transpose(1, 2)
        quantized = encoded + (quantized - encoded).detach()
        return self.out_proj(quantized.float()).float(), indices

    def decode_code(self, indices: torch.Tensor) -> torch.Tensor:
        quantized = F.embedding(indices, self.codebook.weight).transpose(1, 2)
        return self.out_proj(quantized.float()).float()


class ResidualLFQ(nn.Module):
    def __init__(
        self,
        config: Mapping[str, object],
        *,
        device: str | torch.device | None,
    ) -> None:
        super().__init__()
        input_dim = int(config.get("input_dim", 1024))
        rvq_dim = int(config.get("rvq_dim") or input_dim)
        output_dim = int(config.get("output_dim") or input_dim)
        self.rvq_dim = rvq_dim
        self.num_quantizers = int(config.get("num_quantizers", 32))
        codebook_size = int(config.get("codebook_size", 1024))
        codebook_dim = int(config.get("codebook_dim", 8))
        self.input_proj = (
            nn.utils.parametrizations.weight_norm(
                nn.Conv1d(
                    input_dim,
                    rvq_dim,
                    kernel_size=1,
                    device=device,
                    dtype=torch.float32,
                )
            )
            if input_dim != rvq_dim
            else nn.Identity()
        )
        self.output_proj = (
            nn.utils.parametrizations.weight_norm(
                nn.Conv1d(
                    rvq_dim,
                    output_dim,
                    kernel_size=1,
                    device=device,
                    dtype=torch.float32,
                )
            )
            if rvq_dim != output_dim
            else nn.Identity()
        )
        self.quantizers = nn.ModuleList(
            [
                LFQ(
                    input_dim=rvq_dim,
                    codebook_size=codebook_size,
                    codebook_dim=codebook_dim,
                    device=device,
                )
                for _ in range(self.num_quantizers)
            ]
        )
        # Note (Zhang Yiyang): Build this optional cache after loading to remove
        # repeated embedding/projection setup without changing the reference path.
        self.decode_cache: MossAudioTokenizerQuantizerDecoder | None = None

    @torch.no_grad()
    def build_decode_cache(self) -> None:
        """Cache one batched codebook gather and fixed projection weights."""
        self.decode_cache = MossAudioTokenizerQuantizerDecoder(self)

    def clear_decode_cache(self) -> None:
        """Drop the inference-only cache and restore the reference decode path."""
        self.decode_cache = None

    @torch.no_grad()
    def forward(
        self,
        z: torch.Tensor,
        input_lengths: torch.Tensor,
        num_quantizers: int | None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        with torch.autocast(device_type="cuda", enabled=False):
            z = self.input_proj(z.float()).float()
            batch_size, _, max_time = z.shape
            mask = torch.arange(max_time, device=z.device).expand(
                batch_size, max_time
            ) < input_lengths.unsqueeze(1)
            residual = z.clone()
            quantized = torch.zeros_like(z)
            indices = []
            count = (
                self.num_quantizers if num_quantizers is None else int(num_quantizers)
            )
            if not 0 < count <= self.num_quantizers:
                raise ValueError(
                    f"num_quantizers must be in [1, {self.num_quantizers}], got {count}"
                )
            else:
                pass
            update_mask = mask.unsqueeze(1)
            for quantizer in self.quantizers[:count]:
                current, current_indices = quantizer(residual * update_mask)
                quantized += current * update_mask
                residual -= current * update_mask
                indices.append(current_indices)
            return (
                self.output_proj(quantized.float()).float(),
                torch.stack(indices),
                input_lengths,
            )

    @torch.no_grad()
    def decode_codes(self, codes: torch.Tensor) -> torch.Tensor:
        with torch.autocast(device_type=codes.device.type, enabled=False):
            if codes.ndim != 3:
                raise ValueError(
                    f"MOSS quantizer codes must be [N, B, T], got {tuple(codes.shape)}"
                )
            else:
                pass
            count, batch_size, frames = map(int, codes.shape)
            if not 0 < count <= self.num_quantizers:
                raise ValueError(
                    "MOSS quantizer codebook count must be within "
                    f"[1, {self.num_quantizers}], got {count}"
                )
            else:
                pass
            if (
                self.decode_cache is not None
                and codes.device == self.decode_cache.device
            ):
                return self.decode_cache.decode_codes(codes)
            else:
                pass
            decoded = torch.zeros(
                batch_size,
                self.rvq_dim,
                frames,
                device=codes.device,
                dtype=torch.float32,
            )
            for index, quantizer in enumerate(self.quantizers[:count]):
                decoded += quantizer.decode_code(codes[index]).float()
            return self.output_proj(decoded.float()).float()


class MossAudioTokenizerEncoder(nn.Module):
    """Inference-only MOSS-Audio-Tokenizer encoder with repository-owned execution code."""

    def __init__(
        self,
        config: Mapping[str, object],
        *,
        parameter_device: str | torch.device | None = None,
        compute_dtype: torch.dtype | None = None,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
    ) -> None:
        super().__init__()
        self.config = SimpleNamespace(**config)
        sampling_rate = config.get("sampling_rate") or config.get("sample_rate")
        if sampling_rate is None:
            raise ValueError("MOSS-Audio-Tokenizer config lacks sampling_rate")
        else:
            pass
        self.sampling_rate = int(sampling_rate)
        self.downsample_rate = int(config["downsample_rate"])
        self.number_channels = int(config.get("number_channels", 1))
        self.enable_channel_interleave = bool(
            config.get("enable_channel_interleave", self.number_channels > 1)
        )
        configured_compute_dtype = str(config.get("compute_dtype") or "bfloat16")
        resolved_compute_dtype = {
            "bf16": torch.bfloat16,
            "bfloat16": torch.bfloat16,
            "fp32": None,
            "float32": None,
        }.get(configured_compute_dtype)
        if configured_compute_dtype not in {
            "bf16",
            "bfloat16",
            "fp32",
            "float32",
        }:
            raise ValueError(
                f"unsupported codec compute_dtype: {configured_compute_dtype!r}"
            )
        else:
            pass
        requested_compute_dtype = (
            resolved_compute_dtype if compute_dtype is None else compute_dtype
        )
        if requested_compute_dtype not in (
            None,
            torch.float32,
            torch.bfloat16,
        ):
            raise ValueError(
                "compute_dtype must be torch.float32, torch.bfloat16, or None; "
                f"got {requested_compute_dtype!r}"
            )
        else:
            pass
        effective_encoder_dtype = (
            torch.float32
            if requested_compute_dtype is None
            or requested_compute_dtype is torch.float32
            else requested_compute_dtype
        )
        self.compute_dtype = (
            None
            if requested_compute_dtype is torch.float32
            else requested_compute_dtype
        )
        # note (Zhang Yiyang): The compute policy is also the materialized dtype
        # for the encoder weights. This avoids relying on autocast to recast
        # FP32 parameters on every request. The quantizer is intentionally kept
        # FP32 below.
        self.encoder_dtype = effective_encoder_dtype
        self.attention_backend = validate_attention_backend(attention_backend)
        self.uses_moss_audio_tokenizer_v1_weights = "number_channels" not in config

        default_context_duration = float(
            config.get("causal_transformer_context_duration", 10.0)
        )
        channel_factor = (
            self.number_channels
            if self.enable_channel_interleave and self.number_channels > 1
            else 1
        )
        frame_rate = float(self.sampling_rate * channel_factor)
        stages: list[nn.Module] = []
        for stage_config_raw in config["encoder_kwargs"]:
            stage_config = dict(stage_config_raw)
            module_type = stage_config["module_type"]
            if module_type == "PatchedPretransform":
                stage = PatchedPretransform(
                    int(stage_config["patch_size"]),
                    is_downsample=True,
                )
            elif module_type == "Transformer":
                stage_config.setdefault(
                    "attention_implementation",
                    config.get(
                        "attention_implementation",
                        _HF_FLASH_ATTENTION_IMPLEMENTATION,
                    ),
                )
                context_duration = float(
                    stage_config.pop("context_duration", default_context_duration)
                )
                stage = MossAudioTokenizerProjectedTransformer(
                    stage_config,
                    context=int(round(frame_rate * context_duration)),
                    moss_audio_tokenizer_v1_weights=(
                        self.uses_moss_audio_tokenizer_v1_weights
                    ),
                    device=parameter_device,
                    dtype=self.encoder_dtype,
                    attention_backend=self.attention_backend,
                )
            else:
                raise ValueError(f"unsupported MOSS encoder stage: {module_type!r}")
            stages.append(stage)
            frame_rate /= int(getattr(stage, "downsample_ratio", 1))
        self.encoder = nn.ModuleList(stages)

        quantizer_config = dict(config["quantizer_kwargs"])
        quantizer_type = quantizer_config.get(
            "quantizer_type", config.get("quantizer_type", "rlfq")
        )
        if quantizer_type not in {"rlfq", "random_prefix_rlfq"}:
            raise ValueError(
                "repository-local MOSS encoder supports residual LFQ checkpoints; "
                f"got quantizer_type={quantizer_type!r}"
            )
        else:
            pass
        self.quantizer = ResidualLFQ(
            quantizer_config,
            device=parameter_device,
        )

    def supports_packed_attention(self) -> bool:
        device = next(self.parameters()).device
        return all(
            not isinstance(stage, MossAudioTokenizerProjectedTransformer)
            or stage.supports_packed_attention(device, self.encoder_dtype)
            for stage in self.encoder
        )

    def resolve_attention_backend(
        self,
        device: str | torch.device,
        dtype: torch.dtype | None = None,
    ) -> AttentionBackendResolution:
        device = torch.device(device)
        return merge_attention_backend_resolutions(
            [
                stage.resolve_attention_backend(
                    device,
                    self.encoder_dtype if dtype is None else dtype,
                )
                for stage in self.encoder
                if isinstance(stage, MossAudioTokenizerProjectedTransformer)
            ]
        )

    def prepare_waveform_batch(
        self,
        waveforms: list[torch.Tensor],
    ) -> tuple[torch.Tensor, torch.Tensor, list[int]]:
        if not waveforms:
            raise ValueError("waveforms must contain at least one item")
        else:
            pass
        device = waveforms[0].device
        dtype = waveforms[0].dtype
        normalized = []
        lengths_cpu = []
        for index, waveform in enumerate(waveforms):
            if self.number_channels == 1 and waveform.dim() == 1:
                waveform = waveform.unsqueeze(0)
            else:
                pass
            if waveform.dim() != 2 or waveform.shape[0] != self.number_channels:
                raise ValueError(
                    f"waveforms[{index}] must have shape "
                    f"({self.number_channels}, T), got {tuple(waveform.shape)}"
                )
            else:
                pass
            normalized.append(waveform)
            lengths_cpu.append(int(waveform.shape[-1]))
        max_length = max(lengths_cpu)
        batch = torch.zeros(
            len(normalized),
            self.number_channels,
            max_length,
            device=device,
            dtype=dtype,
        )
        for index, waveform in enumerate(normalized):
            batch[index, :, : waveform.shape[-1]] = waveform
        lengths = torch.tensor(lengths_cpu, device=device, dtype=torch.long)
        return batch, lengths, lengths_cpu

    def flatten_channels(
        self,
        input_values: torch.Tensor,
        input_lengths: torch.Tensor,
        input_lengths_cpu: list[int],
    ) -> tuple[torch.Tensor, torch.Tensor, list[int]]:
        remainder = input_values.shape[-1] % self.downsample_rate
        if remainder:
            input_values = F.pad(
                input_values,
                (0, self.downsample_rate - remainder),
            )
        else:
            pass
        if self.number_channels > 1 and self.enable_channel_interleave:
            input_values = (
                input_values.transpose(1, 2)
                .contiguous()
                .view(input_values.shape[0], 1, -1)
            )
            input_lengths = input_lengths * self.number_channels
            input_lengths_cpu = [
                length * self.number_channels for length in input_lengths_cpu
            ]
        else:
            pass
        return input_values, input_lengths, input_lengths_cpu

    @torch.no_grad()
    def batch_encode(
        self,
        waveforms: list[torch.Tensor],
        num_quantizers: int | None = None,
        chunk_duration: float | None = None,
    ) -> MossAudioTokenizerEncoderOutput:
        if chunk_duration is not None:
            raise ValueError(
                "repository-local MOSS encoder only supports full non-streaming "
                "batch_encode (chunk_duration=None)"
            )
        else:
            pass
        hidden, lengths, lengths_cpu = self.prepare_waveform_batch(waveforms)
        hidden, lengths, lengths_cpu = self.flatten_channels(
            hidden,
            lengths,
            lengths_cpu,
        )
        hidden = hidden.to(dtype=self.encoder_dtype)
        for stage in self.encoder:
            if isinstance(stage, MossAudioTokenizerProjectedTransformer):
                hidden, lengths = stage(
                    hidden,
                    lengths,
                    input_lengths_cpu=lengths_cpu,
                )
            else:
                hidden, lengths = stage(hidden, lengths)
                lengths_cpu = [
                    length // int(stage.downsample_ratio) for length in lengths_cpu
                ]
        _, codes, code_lengths = self.quantizer(
            hidden.float(),
            lengths,
            num_quantizers,
        )
        max_valid_length = max(lengths_cpu, default=0)
        return MossAudioTokenizerEncoderOutput(
            audio_codes=codes[:, :, :max_valid_length],
            audio_codes_lengths=code_lengths,
            encoder_hidden_states=hidden[:, :, :max_valid_length].float(),
        )


class MossAudioEncoder:
    """Prepare reference audio and encode it with a shared MOSS encoder."""

    def __init__(self, model: MossAudioTokenizerEncoder, *, device: str) -> None:
        self.model = model
        self.device = str(device)
        config = model.config
        self.sample_rate = resolve_moss_audio_sample_rate(model, config)
        self.number_channels = int(
            getattr(model, "number_channels", getattr(config, "number_channels", 1))
        )

    def encode_paths(
        self,
        paths: Sequence[str | PathLike[str]],
        *,
        num_quantizers: int,
    ) -> list[torch.Tensor]:
        if not paths:
            raise ValueError("paths must contain at least one audio path")
        else:
            pass
        return self.encode_waveforms(
            self.load_paths(paths),
            num_quantizers=num_quantizers,
        )

    def load_paths(
        self,
        paths: Sequence[str | PathLike[str]],
    ) -> list[tuple[torch.Tensor, int]]:
        import torchaudio

        waveforms = []
        for path in paths:
            waveform, sample_rate = torchaudio.load(path)
            if int(sample_rate) != self.sample_rate:
                waveform = torchaudio.functional.resample(
                    waveform=waveform,
                    orig_freq=int(sample_rate),
                    new_freq=self.sample_rate,
                )
            else:
                pass
            waveforms.append((waveform, self.sample_rate))
        return waveforms

    def encode_wavs(
        self,
        waveforms: list[torch.Tensor],
        sample_rate: int,
        *,
        num_quantizers: int,
    ) -> list[torch.Tensor]:
        return self.encode_waveforms(
            [(waveform, int(sample_rate)) for waveform in waveforms],
            num_quantizers=num_quantizers,
        )

    def encode_waveforms(
        self,
        waveforms: list[tuple[torch.Tensor, int]],
        *,
        num_quantizers: int,
    ) -> list[torch.Tensor]:
        if not waveforms:
            raise ValueError("waveforms must contain at least one waveform")
        else:
            pass
        prepared = [
            self.prepare_waveform(waveform, sample_rate)
            for waveform, sample_rate in waveforms
        ]
        with torch.inference_mode():
            encoded = self.model.batch_encode(
                prepared,
                num_quantizers=int(num_quantizers),
            )
        codes = encoded.audio_codes
        lengths = encoded.audio_codes_lengths
        if codes is None or lengths is None:
            raise RuntimeError(
                "MOSS audio encoder returned empty audio_codes/audio_codes_lengths"
            )
        else:
            pass
        codes = codes.detach().to(device="cpu", dtype=torch.long)
        lengths = lengths.detach().to("cpu")
        return [
            codes[:, index, : int(lengths[index])].transpose(0, 1).contiguous()
            for index in range(int(codes.shape[1]))
        ]

    def prepare_waveform(
        self,
        waveform: torch.Tensor,
        sample_rate: int,
    ) -> torch.Tensor:
        if waveform.ndim == 1:
            waveform = waveform.unsqueeze(0)
        else:
            pass
        if waveform.ndim != 2:
            raise ValueError(
                "expected waveform with shape [channels, samples], got "
                f"{tuple(waveform.shape)}"
            )
        else:
            pass
        if self.number_channels == 1:
            if waveform.shape[0] > 1:
                waveform = torch.mean(waveform, dim=0, keepdim=True)
            else:
                pass
        else:
            if waveform.shape[0] == 1:
                waveform = waveform.repeat(self.number_channels, 1)
            elif waveform.shape[0] > self.number_channels:
                waveform = waveform[: self.number_channels]
            else:
                pass
            if waveform.shape[0] != self.number_channels:
                raise ValueError(
                    f"expected {self.number_channels} audio channels, "
                    f"got {waveform.shape[0]}"
                )
            else:
                pass
        if int(sample_rate) != self.sample_rate:
            import torchaudio

            waveform = torchaudio.functional.resample(
                waveform=waveform,
                orig_freq=int(sample_rate),
                new_freq=self.sample_rate,
            )
        else:
            pass
        waveform = self.loudness_normalize(waveform)
        if self.number_channels == 1:
            waveform = waveform.squeeze(0)
        else:
            pass
        return waveform.to(device=self.device, dtype=torch.float32)

    @staticmethod
    def loudness_normalize(waveform: torch.Tensor) -> torch.Tensor:
        waveform = waveform.to(torch.float32)
        if waveform.numel() == 0:
            return waveform
        else:
            pass
        current_dbfs = 10.0 * torch.log10(torch.mean(waveform**2) + 1e-9)
        gain = float(_LOUDNESS_TARGET_DBFS - current_dbfs)
        gain = max(_LOUDNESS_GAIN_MIN_DB, min(gain, _LOUDNESS_GAIN_MAX_DB))
        return waveform * (10.0 ** (gain / 20.0))


def normalize_moss_audio_tokenizer_v1_transformer_state_dict(
    state_dict: dict[str, torch.Tensor],
) -> dict[str, torch.Tensor]:
    """Map MOSS v1 weight names onto the shared Transformer modules."""

    replacements = (
        (".self_attn.in_projs.0.", ".self_attn.in_proj."),
        (".self_attn.out_projs.0.", ".self_attn.out_proj."),
        (".linear1.", ".ffn.linear1."),
        (".linear2.", ".ffn.linear2."),
    )
    normalized = {}
    for name, tensor in state_dict.items():
        normalized_name = name
        for old, new in replacements:
            normalized_name = normalized_name.replace(old, new)
        normalized[normalized_name] = tensor
    return normalized


def load_moss_audio_config(model_path: str) -> tuple[Path, dict[str, JsonValue]]:
    resolved_path = resolve_model_path(str(model_path))
    config_path = resolved_path / "config.json"
    with config_path.open(encoding="utf-8") as config_file:
        config = json.load(config_file)
    if config.get("model_type") != "moss-audio-tokenizer":
        raise ValueError(
            f"expected model_type='moss-audio-tokenizer' in {config_path}, "
            f"got {config.get('model_type')!r}"
        )
    else:
        pass
    return resolved_path, config


def load_moss_audio_component(
    module: nn.Module,
    model_path: Path,
    *,
    prefix: str,
    dtype: torch.dtype,
    device: str | torch.device,
    v1_weights: bool,
) -> nn.Module:
    if v1_weights:
        state_dict = load_weights_by_prefix(str(model_path), prefix=prefix)
        state_dict = normalize_moss_audio_tokenizer_v1_transformer_state_dict(
            state_dict
        )
        try:
            module.load_state_dict(state_dict, strict=True, assign=True)
        except TypeError:
            module.load_state_dict(state_dict, strict=True)
        module = module.to(device=device, dtype=dtype)
        module.eval()
    else:
        module = load_module(
            module,
            str(model_path),
            prefix=prefix,
            dtype=dtype,
            device=device,
            strict=True,
        )
    restore_fp32_compute_parameters(module)
    return module


def fold_weight_norm(module: nn.Module) -> int:
    folded = 0
    for submodule in list(module.modules()):
        while is_parametrized(submodule):
            name = next(iter(submodule.parametrizations.keys()))
            remove_parametrizations(submodule, name, leave_parametrized=True)
            folded += 1
    return folded


def load_moss_audio_quantizer(
    module: nn.Module,
    model_path: Path,
    *,
    device: str | torch.device,
) -> nn.Module:
    module = load_module(
        module,
        str(model_path),
        prefix="quantizer.",
        dtype=torch.float32,
        device=device,
        strict=True,
    )
    folded = fold_weight_norm(module)
    if folded:
        logger.info("Folded %d MOSS quantizer weight_norm parametrizations", folded)
    else:
        pass
    return module


def load_moss_audio_encoder(
    model_path: str,
    *,
    device: str | torch.device,
    compute_dtype: torch.dtype | None = None,
    attention_backend: str = AUTO_ATTENTION_BACKEND,
) -> MossAudioEncoder:
    """Load only encoder/quantizer weights without executing checkpoint code."""

    resolved_path, config = load_moss_audio_config(model_path)

    model = MossAudioTokenizerEncoder(
        config,
        parameter_device="meta",
        compute_dtype=compute_dtype,
        attention_backend=attention_backend,
    )
    target_device = torch.device(device)
    backend_resolution = model.resolve_attention_backend(target_device)
    backend_label = attention_backend_label(backend_resolution)
    model.encoder = load_moss_audio_component(
        model.encoder,
        resolved_path,
        prefix="encoder.",
        dtype=model.encoder_dtype,
        device=device,
        v1_weights=model.uses_moss_audio_tokenizer_v1_weights,
    )
    model.quantizer = load_moss_audio_quantizer(
        model.quantizer,
        resolved_path,
        device=device,
    )
    model.eval()
    logger.info(
        "Loaded repository-local MOSS-Audio-Tokenizer encoder from %s on %s "
        "(channels=%d, attention_backend=%s, encoder_dtype=%s, "
        "compute_dtype=%s)",
        resolved_path,
        device,
        model.number_channels,
        backend_label,
        model.encoder_dtype,
        model.compute_dtype,
    )
    return MossAudioEncoder(model, device=str(device))


class MossAudioTokenizerVocoder(MossAudioTokenizerStreamingModule):
    """Inference-only MOSS quantizer and waveform decoder."""

    def __init__(
        self,
        config: Mapping[str, object],
        *,
        parameter_device: str | torch.device | None = None,
        decoder_dtype: torch.dtype = torch.bfloat16,
        compute_dtype: torch.dtype | None = None,
        attention_backend: str = AUTO_ATTENTION_BACKEND,
    ) -> None:
        super().__init__()
        validate_audio_dtypes(
            component_dtype=decoder_dtype,
            component_name="decoder_dtype",
            compute_dtype=compute_dtype,
        )
        self.config = SimpleNamespace(**config)
        sampling_rate = config.get("sampling_rate") or config.get("sample_rate")
        if sampling_rate is None:
            raise ValueError("MOSS-Audio-Tokenizer config lacks sampling_rate")
        else:
            pass
        self.sampling_rate = int(sampling_rate)
        self.downsample_rate = int(config["downsample_rate"])
        self.number_channels = int(config.get("number_channels", 1))
        self.enable_channel_interleave = bool(
            config.get("enable_channel_interleave", True)
        )
        if not hasattr(self.config, "sampling_rate"):
            self.config.sampling_rate = self.sampling_rate
        else:
            pass
        if not hasattr(self.config, "number_channels"):
            self.config.number_channels = self.number_channels
        else:
            pass
        if not hasattr(self.config, "enable_channel_interleave"):
            self.config.enable_channel_interleave = self.enable_channel_interleave
        else:
            pass
        self.decoder_dtype = decoder_dtype if compute_dtype is None else compute_dtype
        self.compute_dtype = None if compute_dtype is torch.float32 else compute_dtype
        self.attention_backend = validate_attention_backend(attention_backend)
        self.uses_moss_audio_tokenizer_v1_weights = "number_channels" not in config

        quantizer_config = dict(config["quantizer_kwargs"])
        quantizer_type = quantizer_config.get(
            "quantizer_type", config.get("quantizer_type", "rlfq")
        )
        if quantizer_type not in {"rlfq", "random_prefix_rlfq"}:
            raise ValueError(
                "repository-local MOSS-Audio-Tokenizer vocoder supports residual LFQ checkpoints; "
                f"got quantizer_type={quantizer_type!r}"
            )
        else:
            pass
        self.quantizer = ResidualLFQ(
            quantizer_config,
            device=parameter_device,
        )

        self.decoder = MossAudioTokenizerVocoderDecoder(
            config,
            moss_audio_tokenizer_v1_weights=(self.uses_moss_audio_tokenizer_v1_weights),
            device=parameter_device,
            dtype=self.decoder_dtype,
            attention_backend=self.attention_backend,
        )
        # Note (Zhang Yiyang): Keep persistent decoder state separate from the
        # scheduler's compact execution width.
        self.decoder_streaming_modules: list[MossAudioTokenizerStreamingModule] = []
        self.decoder_state_capacity = 0
        self.decoder_real_state_capacity = 0

    def decoder_device(self) -> torch.device:
        parameter = next(self.decoder.parameters(), None)
        if parameter is not None:
            return parameter.device
        else:
            pass
        return self.streaming_device()

    def start_decoder_state_pool(self, total_capacity: int) -> None:
        if self.decoder_streaming_modules:
            raise RuntimeError(
                "MOSS-Audio-Tokenizer decoder state pool is already initialized"
            )
        else:
            pass
        modules = [
            module
            for module in self.decoder.modules()
            if isinstance(module, MossAudioTokenizerStreamingModule)
        ]
        if not modules:
            raise RuntimeError(
                "MOSS-Audio-Tokenizer decoder has no streaming-capable stages"
            )
        else:
            pass
        if any(module.streaming_state is not None for module in modules):
            raise RuntimeError(
                "MOSS-Audio-Tokenizer decoder is already in a streaming session"
            )
        else:
            pass
        try:
            for module in modules:
                module.streaming_state = module.init_streaming_state(total_capacity)
        except BaseException:
            for module in modules:
                module.streaming_state = None
            raise
        self.decoder_streaming_modules = modules

    def initialize_decoder_state_pool(
        self,
        state_capacity: int,
        scratch_capacity: int = 0,
    ) -> None:
        """Allocate persistent decoder state independently of execution width."""
        if not isinstance(state_capacity, int) or isinstance(state_capacity, bool):
            raise TypeError("state_capacity must be an int")
        else:
            pass
        if not isinstance(scratch_capacity, int) or isinstance(scratch_capacity, bool):
            raise TypeError("scratch_capacity must be an int")
        else:
            pass
        if state_capacity <= 0 or scratch_capacity < 0:
            raise ValueError(
                "state_capacity must be > 0 and scratch_capacity must be >= 0; "
                f"got state_capacity={state_capacity}, scratch_capacity={scratch_capacity}"
            )
        else:
            pass
        total_capacity = state_capacity + scratch_capacity
        self.start_decoder_state_pool(total_capacity)
        self.decoder_state_capacity = total_capacity
        self.decoder_real_state_capacity = state_capacity

    def close_decoder_state_pool(self) -> None:
        """Release all decoder streaming state and its persistent cache rows."""
        if not self.decoder_streaming_modules:
            return
        else:
            pass
        for module in reversed(self.decoder_streaming_modules):
            module.streaming_state = None
        self.decoder_streaming_modules = []
        self.decoder_state_capacity = 0
        self.decoder_real_state_capacity = 0

    def reset_decoder_state_slots(self, state_slot_ids: torch.Tensor) -> None:
        """Reset only the requested decoder state slots."""
        if not self.decoder_streaming_modules:
            raise RuntimeError(
                "MOSS-Audio-Tokenizer decoder state pool is not initialized"
            )
        else:
            pass
        if state_slot_ids.ndim != 1:
            raise ValueError(
                f"state_slot_ids must be rank 1, got {tuple(state_slot_ids.shape)}"
            )
        else:
            pass
        if state_slot_ids.dtype != torch.long:
            raise TypeError("state_slot_ids must have dtype torch.long")
        else:
            pass
        device = self.decoder_device()
        if state_slot_ids.device != device:
            raise ValueError(
                f"state_slot_ids must be on {device}, got {state_slot_ids.device}"
            )
        else:
            pass
        if state_slot_ids.numel() == 0:
            return
        else:
            pass
        if device.type != "cuda":
            if bool(torch.any(state_slot_ids < 0)) or bool(
                torch.any(state_slot_ids >= self.decoder_state_capacity)
            ):
                raise ValueError(
                    "state_slot_ids must be in "
                    f"[0, {self.decoder_state_capacity}), got "
                    f"{state_slot_ids.detach().to('cpu').tolist()}"
                )
            else:
                pass
            if torch.unique(state_slot_ids).numel() != state_slot_ids.numel():
                raise ValueError("state_slot_ids must be unique")
            else:
                pass
        else:
            pass
        for module in self.decoder_streaming_modules:
            state = module.streaming_state
            if state is None:
                raise RuntimeError(
                    "MOSS-Audio-Tokenizer decoder streaming state was unexpectedly closed"
                )
            else:
                pass
            state.reset_slots(state_slot_ids)

    def validate_decoder_streaming_inputs(
        self,
        codes: torch.Tensor,
        codes_lengths: torch.Tensor,
        state_slot_ids: torch.Tensor,
        valid_rows: torch.Tensor,
    ) -> StreamingExecutionContext:
        if not self.decoder_streaming_modules:
            raise RuntimeError(
                "MOSS-Audio-Tokenizer decoder state pool is not initialized"
            )
        else:
            pass
        if codes.ndim != 3:
            raise ValueError(
                "codes must have shape [num_quantizers, batch, time], "
                f"got {tuple(codes.shape)}"
            )
        else:
            pass
        device = self.decoder_device()
        if codes.device != device:
            raise ValueError(f"codes must be on {device}, got {codes.device}")
        else:
            pass
        if codes.dtype != torch.long:
            raise TypeError("codes must have dtype torch.long")
        else:
            pass
        _, batch_size, frame_count = codes.shape
        if batch_size <= 0 or frame_count <= 0:
            raise ValueError(
                f"codes must have positive batch/time dimensions, got B={batch_size}, T={frame_count}"
            )
        else:
            pass
        for name, tensor, dtype in (
            ("codes_lengths", codes_lengths, torch.long),
            ("state_slot_ids", state_slot_ids, torch.long),
            ("valid_rows", valid_rows, torch.bool),
        ):
            if tensor.shape != (batch_size,):
                raise ValueError(
                    f"{name} must have shape ({batch_size},), got {tuple(tensor.shape)}"
                )
            else:
                pass
            if tensor.dtype != dtype or tensor.device != device:
                raise TypeError(f"{name} must have dtype {dtype} on {device}")
            else:
                pass
        # note (Zhang Yiyang): Scheduler and graph inputs are trusted device
        # tensors. CPU value checks also cover direct callers without adding
        # GPU synchronization.
        if device.type != "cuda":
            if bool(torch.any(state_slot_ids < 0)) or bool(
                torch.any(state_slot_ids >= self.decoder_state_capacity)
            ):
                raise ValueError(
                    f"state_slot_ids must be in [0, {self.decoder_state_capacity})"
                )
            else:
                pass
            valid_slots = state_slot_ids[valid_rows]
            if bool(torch.any(valid_slots >= self.decoder_real_state_capacity)):
                raise ValueError("valid rows must use real decoder state slots")
            else:
                pass
            if torch.unique(valid_slots).numel() != valid_slots.numel():
                raise ValueError("valid state_slot_ids must be unique")
            else:
                pass
            if bool(torch.any(codes_lengths[valid_rows] != frame_count)):
                raise ValueError(
                    f"valid rows must use the full execution length {frame_count}"
                )
            else:
                pass
            if bool(torch.any(codes_lengths[~valid_rows] != 0)):
                raise ValueError("invalid streaming rows must have codes_lengths=0")
            else:
                pass
        else:
            pass
        return StreamingExecutionContext(state_slot_ids, valid_rows)

    def resolve_attention_backend(
        self,
        device: str | torch.device,
        dtype: torch.dtype | None = None,
    ) -> AttentionBackendResolution:
        decoder_dtype = self.decoder_dtype if dtype is None else dtype
        return self.decoder.resolve_attention_backend(device, decoder_dtype)

    def restore_channels_from_codec(
        self,
        audio: torch.Tensor,
        audio_lengths: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        if self.number_channels == 1 or not self.enable_channel_interleave:
            return audio.float(), audio_lengths
        else:
            pass
        if audio.shape[1] != 1:
            raise ValueError(
                "interleaved MOSS-Audio-Tokenizer decoder output must have one codec channel, "
                f"got {audio.shape[1]}"
            )
        else:
            pass
        audio = (
            audio.squeeze(1)
            .contiguous()
            .view(audio.shape[0], -1, self.number_channels)
            .transpose(1, 2)
            .contiguous()
            .float()
        )
        return (
            audio,
            torch.div(
                audio_lengths,
                self.number_channels,
                rounding_mode="floor",
            ),
        )

    @torch.no_grad()
    def decode_streaming_tensors(
        self,
        codes: torch.Tensor,
        codes_lengths: torch.Tensor,
        state_slot_ids: torch.Tensor,
        valid_rows: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Tensor-only indexed decode boundary for scheduler/graph callers."""
        execution_context = self.validate_decoder_streaming_inputs(
            codes,
            codes_lengths,
            state_slot_ids,
            valid_rows,
        )
        # note (Zhang Yiyang): Match the source codec's autocast boundary,
        # including FP32 LayerNorm. Casting decoder weights/inputs to BF16
        # alone changes streaming PCM.
        autocast_enabled = (
            codes.device.type == "cuda"
            and self.compute_dtype in (torch.float16, torch.bfloat16)
        ) or (codes.device.type == "cpu" and self.compute_dtype is torch.bfloat16)
        hidden = self.quantizer.decode_codes(codes).to(
            dtype=torch.float32 if autocast_enabled else self.decoder_dtype
        )
        with torch.autocast(
            device_type=codes.device.type,
            dtype=self.compute_dtype or self.decoder_dtype,
            enabled=autocast_enabled,
        ):
            audio, audio_lengths = self.decoder(
                hidden,
                codes_lengths,
                execution_context=execution_context,
            )
        audio, audio_lengths = self.restore_channels_from_codec(
            audio,
            audio_lengths,
        )
        invalid = ~valid_rows
        audio = audio.masked_fill(invalid.view(-1, 1, 1), 0)
        audio_lengths = audio_lengths.masked_fill(invalid, 0)
        return audio, audio_lengths


class MossAudioVocoder:
    """Narrow wrapper used by the MOSS-TTS Delay vocoder stage."""

    def __init__(self, model: MossAudioTokenizerVocoder, *, device: str) -> None:
        self.model = model
        self.device = str(device)
        self.sample_rate = int(model.sampling_rate)

    @torch.no_grad()
    def decode_codes(
        self,
        codes: torch.Tensor | list[torch.Tensor],
    ) -> list[torch.Tensor]:
        if isinstance(codes, torch.Tensor):
            codes = [codes]
        else:
            pass
        if not codes:
            return []
        else:
            pass
        codes_nq_t = [
            item.transpose(0, 1).contiguous().to(device=self.device, dtype=torch.long)
            for item in codes
        ]
        count = int(codes_nq_t[0].shape[0])
        if any(int(item.shape[0]) != count for item in codes_nq_t):
            raise ValueError("all audio-code rows must use the same quantizer count")
        else:
            pass
        lengths_cpu = [int(item.shape[1]) for item in codes_nq_t]
        max_length = max(lengths_cpu)
        audio_codes = torch.zeros(
            count,
            len(codes_nq_t),
            max_length,
            device=self.device,
            dtype=torch.long,
        )
        for index, item in enumerate(codes_nq_t):
            audio_codes[:, index, : item.shape[1]] = item
        lengths = torch.tensor(lengths_cpu, device=self.device, dtype=torch.int32)
        hidden = self.model.quantizer.decode_codes(audio_codes)
        hidden = hidden.to(dtype=self.model.decoder_dtype)
        audio, _ = self.model.decoder(
            hidden,
            lengths,
            input_lengths_cpu=lengths_cpu,
        )
        output_lengths = self.model.decoder.output_lengths(lengths_cpu)
        return [
            audio[index, 0, :length].detach().to(device="cpu", dtype=torch.float32)
            for index, length in enumerate(output_lengths)
        ]


def load_moss_audio_vocoder(
    model_path: str,
    *,
    device: str | torch.device,
    decoder_dtype: torch.dtype = torch.bfloat16,
    compute_dtype: torch.dtype | None = None,
    attention_backend: str = AUTO_ATTENTION_BACKEND,
) -> MossAudioVocoder:
    """Load only quantizer/decoder weights without executing checkpoint code."""

    resolved_path, config = load_moss_audio_config(model_path)

    model = MossAudioTokenizerVocoder(
        config,
        parameter_device="meta",
        decoder_dtype=decoder_dtype,
        compute_dtype=compute_dtype,
        attention_backend=attention_backend,
    )
    target_device = torch.device(device)
    backend_resolution = model.resolve_attention_backend(target_device)
    backend_label = attention_backend_label(backend_resolution)
    model.quantizer = load_moss_audio_quantizer(
        model.quantizer,
        resolved_path,
        device=device,
    )
    model.quantizer.build_decode_cache()
    model.decoder = load_moss_audio_component(
        model.decoder,
        resolved_path,
        prefix="decoder.",
        dtype=model.decoder_dtype,
        device=device,
        v1_weights=model.uses_moss_audio_tokenizer_v1_weights,
    )
    model.eval()
    logger.info(
        "Loaded repository-local MOSS-Audio-Tokenizer vocoder from %s on %s "
        "(attention_backend=%s, decoder_dtype=%s, compute_dtype=%s)",
        resolved_path,
        device,
        backend_label,
        model.decoder_dtype,
        model.compute_dtype,
    )
    return MossAudioVocoder(model, device=str(device))
