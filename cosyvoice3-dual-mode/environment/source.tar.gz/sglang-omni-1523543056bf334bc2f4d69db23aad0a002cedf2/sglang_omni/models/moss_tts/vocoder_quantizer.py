# SPDX-License-Identifier: Apache-2.0
"""Inference-only quantizer decode helpers for MOSS-TTS Delay."""

from __future__ import annotations

import torch
from torch import nn
from torch.nn import functional as F


def pointwise_conv1d_parameters(
    module: nn.Module,
) -> tuple[torch.Tensor, torch.Tensor | None]:
    if not isinstance(module, nn.Conv1d):
        raise TypeError(f"expected Conv1d, got {module.__class__.__name__}")
    else:
        pass
    if (
        module.kernel_size != (1,)
        or module.stride != (1,)
        or module.padding != (0,)
        or module.dilation != (1,)
        or module.groups != 1
    ):
        raise ValueError("cached quantizer decode requires pointwise Conv1d")
    else:
        pass
    weight = module.weight.detach().squeeze(-1).to(dtype=torch.float32)
    bias = None if module.bias is None else module.bias.detach().to(dtype=torch.float32)
    return weight, bias


class MossAudioTokenizerQuantizerDecoder:
    """Cache FP32 codebooks and projections used by residual codec decode."""

    def __init__(self, source: nn.Module) -> None:
        quantizers = list(getattr(source, "quantizers", ()))
        if not quantizers:
            raise ValueError("MOSS quantizer has no residual codebooks")
        else:
            pass

        codebooks: list[torch.Tensor] = []
        weights: list[torch.Tensor] = []
        biases: list[torch.Tensor | None] = []
        codebook_size = 0
        output_dim = 0
        for quantizer in quantizers:
            codebook = getattr(getattr(quantizer, "codebook", None), "weight", None)
            if not isinstance(codebook, torch.Tensor) or codebook.ndim != 2:
                raise TypeError("MOSS quantizer codebook must be a 2D tensor")
            else:
                pass
            weight, bias = pointwise_conv1d_parameters(quantizer.out_proj)
            if int(codebook.shape[1]) != int(weight.shape[1]):
                raise ValueError("MOSS codebook and projection dimensions do not match")
            else:
                pass
            if not codebooks:
                codebook_size = int(codebook.shape[0])
                output_dim = int(weight.shape[0])
            elif (
                tuple(codebook.shape) != tuple(codebooks[0].shape)
                or int(weight.shape[0]) != output_dim
            ):
                raise ValueError(
                    "MOSS residual codebooks must share input and output sizes"
                )
            else:
                pass
            codebooks.append(codebook.detach().to(dtype=torch.float32))
            weights.append(weight)
            biases.append(bias)

        output_proj = getattr(source, "output_proj", None)
        if isinstance(output_proj, nn.Identity):
            output_weight = None
            output_bias = None
        else:
            output_weight, output_bias = pointwise_conv1d_parameters(output_proj)
            if int(output_weight.shape[1]) != output_dim:
                raise ValueError(
                    "MOSS quantizer output projection has an unexpected input size"
                )
            else:
                pass

        self.num_quantizers = len(quantizers)
        self.output_dim = output_dim
        self.flat_codebooks = torch.stack(codebooks).flatten(0, 1)
        self.weights = tuple(weights)
        self.biases = tuple(biases)
        self.offsets = (
            torch.arange(
                self.num_quantizers,
                device=self.flat_codebooks.device,
                dtype=torch.long,
            )
            * codebook_size
        ).view(-1, 1, 1)
        self.output_weight = output_weight
        self.output_bias = output_bias

    @property
    def device(self) -> torch.device:
        return self.flat_codebooks.device

    def decode_codes(self, codes: torch.Tensor) -> torch.Tensor:
        if codes.ndim != 3:
            raise ValueError(
                f"MOSS quantizer codes must be [N, B, T], got {tuple(codes.shape)}"
            )
        else:
            pass
        num_quantizers = int(codes.shape[0])
        if num_quantizers <= 0 or num_quantizers > self.num_quantizers:
            raise ValueError(
                "MOSS quantizer codebook count must be within "
                f"[1, {self.num_quantizers}], got {num_quantizers}"
            )
        else:
            pass
        if codes.device != self.flat_codebooks.device:
            raise ValueError(
                "MOSS quantizer codes and cached weights must share one device"
            )
        else:
            pass

        _, batch_size, frames = codes.shape
        decoded = torch.zeros(
            batch_size,
            self.output_dim,
            frames,
            device=codes.device,
            dtype=torch.float32,
        )
        embedded = F.embedding(
            codes + self.offsets[:num_quantizers],
            self.flat_codebooks,
        )
        for index in range(num_quantizers):
            decoded.add_(
                F.conv1d(
                    embedded[index].transpose(1, 2),
                    self.weights[index].unsqueeze(-1),
                    self.biases[index],
                )
            )
        if self.output_weight is not None:
            decoded = F.conv1d(
                decoded,
                self.output_weight.unsqueeze(-1),
                self.output_bias,
            )
        else:
            pass
        return decoded


__all__ = ["MossAudioTokenizerQuantizerDecoder"]
